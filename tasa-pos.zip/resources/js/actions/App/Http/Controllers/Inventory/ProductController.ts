import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Inventory\ProductController::index
 * @see app/Http/Controllers/Inventory/ProductController.php:33
 * @route '/inventory/products'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/inventory/products',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::index
 * @see app/Http/Controllers/Inventory/ProductController.php:33
 * @route '/inventory/products'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::index
 * @see app/Http/Controllers/Inventory/ProductController.php:33
 * @route '/inventory/products'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\ProductController::index
 * @see app/Http/Controllers/Inventory/ProductController.php:33
 * @route '/inventory/products'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::index
 * @see app/Http/Controllers/Inventory/ProductController.php:33
 * @route '/inventory/products'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::index
 * @see app/Http/Controllers/Inventory/ProductController.php:33
 * @route '/inventory/products'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\ProductController::index
 * @see app/Http/Controllers/Inventory/ProductController.php:33
 * @route '/inventory/products'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::store
 * @see app/Http/Controllers/Inventory/ProductController.php:182
 * @route '/inventory/products'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/inventory/products',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::store
 * @see app/Http/Controllers/Inventory/ProductController.php:182
 * @route '/inventory/products'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::store
 * @see app/Http/Controllers/Inventory/ProductController.php:182
 * @route '/inventory/products'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::store
 * @see app/Http/Controllers/Inventory/ProductController.php:182
 * @route '/inventory/products'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::store
 * @see app/Http/Controllers/Inventory/ProductController.php:182
 * @route '/inventory/products'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::update
 * @see app/Http/Controllers/Inventory/ProductController.php:192
 * @route '/inventory/products/{product}'
 */
export const update = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/inventory/products/{product}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::update
 * @see app/Http/Controllers/Inventory/ProductController.php:192
 * @route '/inventory/products/{product}'
 */
update.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return update.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::update
 * @see app/Http/Controllers/Inventory/ProductController.php:192
 * @route '/inventory/products/{product}'
 */
update.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::update
 * @see app/Http/Controllers/Inventory/ProductController.php:192
 * @route '/inventory/products/{product}'
 */
    const updateForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::update
 * @see app/Http/Controllers/Inventory/ProductController.php:192
 * @route '/inventory/products/{product}'
 */
        updateForm.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::destroy
 * @see app/Http/Controllers/Inventory/ProductController.php:202
 * @route '/inventory/products/{product}'
 */
export const destroy = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/inventory/products/{product}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::destroy
 * @see app/Http/Controllers/Inventory/ProductController.php:202
 * @route '/inventory/products/{product}'
 */
destroy.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return destroy.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::destroy
 * @see app/Http/Controllers/Inventory/ProductController.php:202
 * @route '/inventory/products/{product}'
 */
destroy.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::destroy
 * @see app/Http/Controllers/Inventory/ProductController.php:202
 * @route '/inventory/products/{product}'
 */
    const destroyForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::destroy
 * @see app/Http/Controllers/Inventory/ProductController.php:202
 * @route '/inventory/products/{product}'
 */
        destroyForm.delete = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::updateMinStock
 * @see app/Http/Controllers/Inventory/ProductController.php:215
 * @route '/inventory/products/{product}/min-stock'
 */
export const updateMinStock = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateMinStock.url(args, options),
    method: 'patch',
})

updateMinStock.definition = {
    methods: ["patch"],
    url: '/inventory/products/{product}/min-stock',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::updateMinStock
 * @see app/Http/Controllers/Inventory/ProductController.php:215
 * @route '/inventory/products/{product}/min-stock'
 */
updateMinStock.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return updateMinStock.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::updateMinStock
 * @see app/Http/Controllers/Inventory/ProductController.php:215
 * @route '/inventory/products/{product}/min-stock'
 */
updateMinStock.patch = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateMinStock.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::updateMinStock
 * @see app/Http/Controllers/Inventory/ProductController.php:215
 * @route '/inventory/products/{product}/min-stock'
 */
    const updateMinStockForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateMinStock.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::updateMinStock
 * @see app/Http/Controllers/Inventory/ProductController.php:215
 * @route '/inventory/products/{product}/min-stock'
 */
        updateMinStockForm.patch = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateMinStock.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateMinStock.form = updateMinStockForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::addStock
 * @see app/Http/Controllers/Inventory/ProductController.php:239
 * @route '/inventory/products/{product}/add-stock'
 */
export const addStock = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addStock.url(args, options),
    method: 'post',
})

addStock.definition = {
    methods: ["post"],
    url: '/inventory/products/{product}/add-stock',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::addStock
 * @see app/Http/Controllers/Inventory/ProductController.php:239
 * @route '/inventory/products/{product}/add-stock'
 */
addStock.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return addStock.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::addStock
 * @see app/Http/Controllers/Inventory/ProductController.php:239
 * @route '/inventory/products/{product}/add-stock'
 */
addStock.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addStock.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::addStock
 * @see app/Http/Controllers/Inventory/ProductController.php:239
 * @route '/inventory/products/{product}/add-stock'
 */
    const addStockForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addStock.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::addStock
 * @see app/Http/Controllers/Inventory/ProductController.php:239
 * @route '/inventory/products/{product}/add-stock'
 */
        addStockForm.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addStock.url(args, options),
            method: 'post',
        })
    
    addStock.form = addStockForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::adjustStock
 * @see app/Http/Controllers/Inventory/ProductController.php:261
 * @route '/inventory/products/{product}/adjust-stock'
 */
export const adjustStock = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock.url(args, options),
    method: 'post',
})

adjustStock.definition = {
    methods: ["post"],
    url: '/inventory/products/{product}/adjust-stock',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::adjustStock
 * @see app/Http/Controllers/Inventory/ProductController.php:261
 * @route '/inventory/products/{product}/adjust-stock'
 */
adjustStock.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return adjustStock.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::adjustStock
 * @see app/Http/Controllers/Inventory/ProductController.php:261
 * @route '/inventory/products/{product}/adjust-stock'
 */
adjustStock.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::adjustStock
 * @see app/Http/Controllers/Inventory/ProductController.php:261
 * @route '/inventory/products/{product}/adjust-stock'
 */
    const adjustStockForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adjustStock.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::adjustStock
 * @see app/Http/Controllers/Inventory/ProductController.php:261
 * @route '/inventory/products/{product}/adjust-stock'
 */
        adjustStockForm.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adjustStock.url(args, options),
            method: 'post',
        })
    
    adjustStock.form = adjustStockForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::movements
 * @see app/Http/Controllers/Inventory/ProductController.php:289
 * @route '/inventory/products/{product}/movements'
 */
export const movements = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements.url(args, options),
    method: 'get',
})

movements.definition = {
    methods: ["get","head"],
    url: '/inventory/products/{product}/movements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::movements
 * @see app/Http/Controllers/Inventory/ProductController.php:289
 * @route '/inventory/products/{product}/movements'
 */
movements.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return movements.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::movements
 * @see app/Http/Controllers/Inventory/ProductController.php:289
 * @route '/inventory/products/{product}/movements'
 */
movements.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\ProductController::movements
 * @see app/Http/Controllers/Inventory/ProductController.php:289
 * @route '/inventory/products/{product}/movements'
 */
movements.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: movements.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::movements
 * @see app/Http/Controllers/Inventory/ProductController.php:289
 * @route '/inventory/products/{product}/movements'
 */
    const movementsForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: movements.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::movements
 * @see app/Http/Controllers/Inventory/ProductController.php:289
 * @route '/inventory/products/{product}/movements'
 */
        movementsForm.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movements.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\ProductController::movements
 * @see app/Http/Controllers/Inventory/ProductController.php:289
 * @route '/inventory/products/{product}/movements'
 */
        movementsForm.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movements.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    movements.form = movementsForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::downloadTemplate
 * @see app/Http/Controllers/Inventory/ProductController.php:327
 * @route '/inventory/products/import/template'
 */
export const downloadTemplate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadTemplate.url(options),
    method: 'get',
})

downloadTemplate.definition = {
    methods: ["get","head"],
    url: '/inventory/products/import/template',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::downloadTemplate
 * @see app/Http/Controllers/Inventory/ProductController.php:327
 * @route '/inventory/products/import/template'
 */
downloadTemplate.url = (options?: RouteQueryOptions) => {
    return downloadTemplate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::downloadTemplate
 * @see app/Http/Controllers/Inventory/ProductController.php:327
 * @route '/inventory/products/import/template'
 */
downloadTemplate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadTemplate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\ProductController::downloadTemplate
 * @see app/Http/Controllers/Inventory/ProductController.php:327
 * @route '/inventory/products/import/template'
 */
downloadTemplate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadTemplate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::downloadTemplate
 * @see app/Http/Controllers/Inventory/ProductController.php:327
 * @route '/inventory/products/import/template'
 */
    const downloadTemplateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadTemplate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::downloadTemplate
 * @see app/Http/Controllers/Inventory/ProductController.php:327
 * @route '/inventory/products/import/template'
 */
        downloadTemplateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadTemplate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\ProductController::downloadTemplate
 * @see app/Http/Controllers/Inventory/ProductController.php:327
 * @route '/inventory/products/import/template'
 */
        downloadTemplateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadTemplate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadTemplate.form = downloadTemplateForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::previewImport
 * @see app/Http/Controllers/Inventory/ProductController.php:339
 * @route '/inventory/products/import/preview'
 */
export const previewImport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: previewImport.url(options),
    method: 'post',
})

previewImport.definition = {
    methods: ["post"],
    url: '/inventory/products/import/preview',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::previewImport
 * @see app/Http/Controllers/Inventory/ProductController.php:339
 * @route '/inventory/products/import/preview'
 */
previewImport.url = (options?: RouteQueryOptions) => {
    return previewImport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::previewImport
 * @see app/Http/Controllers/Inventory/ProductController.php:339
 * @route '/inventory/products/import/preview'
 */
previewImport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: previewImport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::previewImport
 * @see app/Http/Controllers/Inventory/ProductController.php:339
 * @route '/inventory/products/import/preview'
 */
    const previewImportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: previewImport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::previewImport
 * @see app/Http/Controllers/Inventory/ProductController.php:339
 * @route '/inventory/products/import/preview'
 */
        previewImportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: previewImport.url(options),
            method: 'post',
        })
    
    previewImport.form = previewImportForm
/**
* @see \App\Http\Controllers\Inventory\ProductController::commitImport
 * @see app/Http/Controllers/Inventory/ProductController.php:359
 * @route '/inventory/products/import/commit'
 */
export const commitImport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: commitImport.url(options),
    method: 'post',
})

commitImport.definition = {
    methods: ["post"],
    url: '/inventory/products/import/commit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\ProductController::commitImport
 * @see app/Http/Controllers/Inventory/ProductController.php:359
 * @route '/inventory/products/import/commit'
 */
commitImport.url = (options?: RouteQueryOptions) => {
    return commitImport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\ProductController::commitImport
 * @see app/Http/Controllers/Inventory/ProductController.php:359
 * @route '/inventory/products/import/commit'
 */
commitImport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: commitImport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\ProductController::commitImport
 * @see app/Http/Controllers/Inventory/ProductController.php:359
 * @route '/inventory/products/import/commit'
 */
    const commitImportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: commitImport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\ProductController::commitImport
 * @see app/Http/Controllers/Inventory/ProductController.php:359
 * @route '/inventory/products/import/commit'
 */
        commitImportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: commitImport.url(options),
            method: 'post',
        })
    
    commitImport.form = commitImportForm
const ProductController = { index, store, update, destroy, updateMinStock, addStock, adjustStock, movements, downloadTemplate, previewImport, commitImport }

export default ProductController