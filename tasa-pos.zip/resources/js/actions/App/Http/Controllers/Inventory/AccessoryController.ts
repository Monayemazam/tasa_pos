import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::index
 * @see app/Http/Controllers/Inventory/AccessoryController.php:29
 * @route '/inventory/accessories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/inventory/accessories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::index
 * @see app/Http/Controllers/Inventory/AccessoryController.php:29
 * @route '/inventory/accessories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::index
 * @see app/Http/Controllers/Inventory/AccessoryController.php:29
 * @route '/inventory/accessories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::index
 * @see app/Http/Controllers/Inventory/AccessoryController.php:29
 * @route '/inventory/accessories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::index
 * @see app/Http/Controllers/Inventory/AccessoryController.php:29
 * @route '/inventory/accessories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::index
 * @see app/Http/Controllers/Inventory/AccessoryController.php:29
 * @route '/inventory/accessories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::index
 * @see app/Http/Controllers/Inventory/AccessoryController.php:29
 * @route '/inventory/accessories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:159
 * @route '/inventory/accessories/items'
 */
export const storeItem = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeItem.url(options),
    method: 'post',
})

storeItem.definition = {
    methods: ["post"],
    url: '/inventory/accessories/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:159
 * @route '/inventory/accessories/items'
 */
storeItem.url = (options?: RouteQueryOptions) => {
    return storeItem.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:159
 * @route '/inventory/accessories/items'
 */
storeItem.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeItem.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:159
 * @route '/inventory/accessories/items'
 */
    const storeItemForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeItem.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:159
 * @route '/inventory/accessories/items'
 */
        storeItemForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeItem.url(options),
            method: 'post',
        })
    
    storeItem.form = storeItemForm
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::updateItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:169
 * @route '/inventory/accessories/items/{item}'
 */
export const updateItem = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

updateItem.definition = {
    methods: ["put"],
    url: '/inventory/accessories/items/{item}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::updateItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:169
 * @route '/inventory/accessories/items/{item}'
 */
updateItem.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return updateItem.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::updateItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:169
 * @route '/inventory/accessories/items/{item}'
 */
updateItem.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::updateItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:169
 * @route '/inventory/accessories/items/{item}'
 */
    const updateItemForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateItem.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::updateItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:169
 * @route '/inventory/accessories/items/{item}'
 */
        updateItemForm.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateItem.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateItem.form = updateItemForm
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::destroyItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:179
 * @route '/inventory/accessories/items/{item}'
 */
export const destroyItem = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyItem.url(args, options),
    method: 'delete',
})

destroyItem.definition = {
    methods: ["delete"],
    url: '/inventory/accessories/items/{item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::destroyItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:179
 * @route '/inventory/accessories/items/{item}'
 */
destroyItem.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return destroyItem.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::destroyItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:179
 * @route '/inventory/accessories/items/{item}'
 */
destroyItem.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyItem.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::destroyItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:179
 * @route '/inventory/accessories/items/{item}'
 */
    const destroyItemForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyItem.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::destroyItem
 * @see app/Http/Controllers/Inventory/AccessoryController.php:179
 * @route '/inventory/accessories/items/{item}'
 */
        destroyItemForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyItem.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyItem.form = destroyItemForm
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::storePurchase
 * @see app/Http/Controllers/Inventory/AccessoryController.php:192
 * @route '/inventory/accessories/purchases'
 */
export const storePurchase = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePurchase.url(options),
    method: 'post',
})

storePurchase.definition = {
    methods: ["post"],
    url: '/inventory/accessories/purchases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::storePurchase
 * @see app/Http/Controllers/Inventory/AccessoryController.php:192
 * @route '/inventory/accessories/purchases'
 */
storePurchase.url = (options?: RouteQueryOptions) => {
    return storePurchase.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::storePurchase
 * @see app/Http/Controllers/Inventory/AccessoryController.php:192
 * @route '/inventory/accessories/purchases'
 */
storePurchase.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePurchase.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::storePurchase
 * @see app/Http/Controllers/Inventory/AccessoryController.php:192
 * @route '/inventory/accessories/purchases'
 */
    const storePurchaseForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storePurchase.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::storePurchase
 * @see app/Http/Controllers/Inventory/AccessoryController.php:192
 * @route '/inventory/accessories/purchases'
 */
        storePurchaseForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storePurchase.url(options),
            method: 'post',
        })
    
    storePurchase.form = storePurchaseForm
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeConsumption
 * @see app/Http/Controllers/Inventory/AccessoryController.php:207
 * @route '/inventory/accessories/consumptions'
 */
export const storeConsumption = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeConsumption.url(options),
    method: 'post',
})

storeConsumption.definition = {
    methods: ["post"],
    url: '/inventory/accessories/consumptions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeConsumption
 * @see app/Http/Controllers/Inventory/AccessoryController.php:207
 * @route '/inventory/accessories/consumptions'
 */
storeConsumption.url = (options?: RouteQueryOptions) => {
    return storeConsumption.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeConsumption
 * @see app/Http/Controllers/Inventory/AccessoryController.php:207
 * @route '/inventory/accessories/consumptions'
 */
storeConsumption.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeConsumption.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeConsumption
 * @see app/Http/Controllers/Inventory/AccessoryController.php:207
 * @route '/inventory/accessories/consumptions'
 */
    const storeConsumptionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeConsumption.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::storeConsumption
 * @see app/Http/Controllers/Inventory/AccessoryController.php:207
 * @route '/inventory/accessories/consumptions'
 */
        storeConsumptionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeConsumption.url(options),
            method: 'post',
        })
    
    storeConsumption.form = storeConsumptionForm
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjust-stock'
 */
const adjustStock0a4639ae99186f7337edbe6df1fc4333 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock0a4639ae99186f7337edbe6df1fc4333.url(options),
    method: 'post',
})

adjustStock0a4639ae99186f7337edbe6df1fc4333.definition = {
    methods: ["post"],
    url: '/inventory/accessories/adjust-stock',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjust-stock'
 */
adjustStock0a4639ae99186f7337edbe6df1fc4333.url = (options?: RouteQueryOptions) => {
    return adjustStock0a4639ae99186f7337edbe6df1fc4333.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjust-stock'
 */
adjustStock0a4639ae99186f7337edbe6df1fc4333.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock0a4639ae99186f7337edbe6df1fc4333.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjust-stock'
 */
    const adjustStock0a4639ae99186f7337edbe6df1fc4333Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adjustStock0a4639ae99186f7337edbe6df1fc4333.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjust-stock'
 */
        adjustStock0a4639ae99186f7337edbe6df1fc4333Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adjustStock0a4639ae99186f7337edbe6df1fc4333.url(options),
            method: 'post',
        })
    
    adjustStock0a4639ae99186f7337edbe6df1fc4333.form = adjustStock0a4639ae99186f7337edbe6df1fc4333Form
    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjustments'
 */
const adjustStock04a868fbb1747a875b4957f3c758944a = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock04a868fbb1747a875b4957f3c758944a.url(options),
    method: 'post',
})

adjustStock04a868fbb1747a875b4957f3c758944a.definition = {
    methods: ["post"],
    url: '/inventory/accessories/adjustments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjustments'
 */
adjustStock04a868fbb1747a875b4957f3c758944a.url = (options?: RouteQueryOptions) => {
    return adjustStock04a868fbb1747a875b4957f3c758944a.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjustments'
 */
adjustStock04a868fbb1747a875b4957f3c758944a.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock04a868fbb1747a875b4957f3c758944a.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjustments'
 */
    const adjustStock04a868fbb1747a875b4957f3c758944aForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adjustStock04a868fbb1747a875b4957f3c758944a.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::adjustStock
 * @see app/Http/Controllers/Inventory/AccessoryController.php:222
 * @route '/inventory/accessories/adjustments'
 */
        adjustStock04a868fbb1747a875b4957f3c758944aForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adjustStock04a868fbb1747a875b4957f3c758944a.url(options),
            method: 'post',
        })
    
    adjustStock04a868fbb1747a875b4957f3c758944a.form = adjustStock04a868fbb1747a875b4957f3c758944aForm

/**
* Multiple routes resolve to \App\Http\Controllers\Inventory\AccessoryController::adjustStock, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `adjustStock['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const adjustStock = {
    '/inventory/accessories/adjust-stock': adjustStock0a4639ae99186f7337edbe6df1fc4333,
    '/inventory/accessories/adjustments': adjustStock04a868fbb1747a875b4957f3c758944a,
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/items/{item}/movements'
 */
const movements5bdbb3cedecd0ca7bbac41f573269c17 = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements5bdbb3cedecd0ca7bbac41f573269c17.url(args, options),
    method: 'get',
})

movements5bdbb3cedecd0ca7bbac41f573269c17.definition = {
    methods: ["get","head"],
    url: '/inventory/accessories/items/{item}/movements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/items/{item}/movements'
 */
movements5bdbb3cedecd0ca7bbac41f573269c17.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return movements5bdbb3cedecd0ca7bbac41f573269c17.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/items/{item}/movements'
 */
movements5bdbb3cedecd0ca7bbac41f573269c17.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements5bdbb3cedecd0ca7bbac41f573269c17.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/items/{item}/movements'
 */
movements5bdbb3cedecd0ca7bbac41f573269c17.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: movements5bdbb3cedecd0ca7bbac41f573269c17.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/items/{item}/movements'
 */
    const movements5bdbb3cedecd0ca7bbac41f573269c17Form = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: movements5bdbb3cedecd0ca7bbac41f573269c17.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/items/{item}/movements'
 */
        movements5bdbb3cedecd0ca7bbac41f573269c17Form.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movements5bdbb3cedecd0ca7bbac41f573269c17.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/items/{item}/movements'
 */
        movements5bdbb3cedecd0ca7bbac41f573269c17Form.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movements5bdbb3cedecd0ca7bbac41f573269c17.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    movements5bdbb3cedecd0ca7bbac41f573269c17.form = movements5bdbb3cedecd0ca7bbac41f573269c17Form
    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/{item}/movements'
 */
const movements2ccfa479f0f418c4f4be51473dbe3ad1 = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements2ccfa479f0f418c4f4be51473dbe3ad1.url(args, options),
    method: 'get',
})

movements2ccfa479f0f418c4f4be51473dbe3ad1.definition = {
    methods: ["get","head"],
    url: '/inventory/accessories/{item}/movements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/{item}/movements'
 */
movements2ccfa479f0f418c4f4be51473dbe3ad1.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return movements2ccfa479f0f418c4f4be51473dbe3ad1.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/{item}/movements'
 */
movements2ccfa479f0f418c4f4be51473dbe3ad1.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements2ccfa479f0f418c4f4be51473dbe3ad1.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/{item}/movements'
 */
movements2ccfa479f0f418c4f4be51473dbe3ad1.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: movements2ccfa479f0f418c4f4be51473dbe3ad1.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/{item}/movements'
 */
    const movements2ccfa479f0f418c4f4be51473dbe3ad1Form = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: movements2ccfa479f0f418c4f4be51473dbe3ad1.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/{item}/movements'
 */
        movements2ccfa479f0f418c4f4be51473dbe3ad1Form.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movements2ccfa479f0f418c4f4be51473dbe3ad1.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\AccessoryController::movements
 * @see app/Http/Controllers/Inventory/AccessoryController.php:245
 * @route '/inventory/accessories/{item}/movements'
 */
        movements2ccfa479f0f418c4f4be51473dbe3ad1Form.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movements2ccfa479f0f418c4f4be51473dbe3ad1.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    movements2ccfa479f0f418c4f4be51473dbe3ad1.form = movements2ccfa479f0f418c4f4be51473dbe3ad1Form

/**
* Multiple routes resolve to \App\Http\Controllers\Inventory\AccessoryController::movements, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `movements['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const movements = {
    '/inventory/accessories/items/{item}/movements': movements5bdbb3cedecd0ca7bbac41f573269c17,
    '/inventory/accessories/{item}/movements': movements2ccfa479f0f418c4f4be51473dbe3ad1,
}

const AccessoryController = { index, storeItem, updateItem, destroyItem, storePurchase, storeConsumption, adjustStock, movements }

export default AccessoryController