import ProductController from './ProductController'
import ProductCategoryController from './ProductCategoryController'
import LeatherController from './LeatherController'
import AccessoryController from './AccessoryController'
import StockAdjustmentController from './StockAdjustmentController'
const Inventory = {
    ProductController: Object.assign(ProductController, ProductController),
ProductCategoryController: Object.assign(ProductCategoryController, ProductCategoryController),
LeatherController: Object.assign(LeatherController, LeatherController),
AccessoryController: Object.assign(AccessoryController, AccessoryController),
StockAdjustmentController: Object.assign(StockAdjustmentController, StockAdjustmentController),
}

export default Inventory