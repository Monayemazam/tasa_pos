import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::index
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:31
 * @route '/inventory/adjustments'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/inventory/adjustments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::index
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:31
 * @route '/inventory/adjustments'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::index
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:31
 * @route '/inventory/adjustments'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::index
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:31
 * @route '/inventory/adjustments'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::index
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:31
 * @route '/inventory/adjustments'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::index
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:31
 * @route '/inventory/adjustments'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::index
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:31
 * @route '/inventory/adjustments'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::store
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:64
 * @route '/inventory/adjustments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/inventory/adjustments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::store
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:64
 * @route '/inventory/adjustments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::store
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:64
 * @route '/inventory/adjustments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::store
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:64
 * @route '/inventory/adjustments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::store
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:64
 * @route '/inventory/adjustments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::getItemsByType
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:76
 * @route '/inventory/adjustments/items'
 */
export const getItemsByType = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getItemsByType.url(options),
    method: 'get',
})

getItemsByType.definition = {
    methods: ["get","head"],
    url: '/inventory/adjustments/items',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::getItemsByType
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:76
 * @route '/inventory/adjustments/items'
 */
getItemsByType.url = (options?: RouteQueryOptions) => {
    return getItemsByType.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::getItemsByType
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:76
 * @route '/inventory/adjustments/items'
 */
getItemsByType.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getItemsByType.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::getItemsByType
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:76
 * @route '/inventory/adjustments/items'
 */
getItemsByType.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getItemsByType.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::getItemsByType
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:76
 * @route '/inventory/adjustments/items'
 */
    const getItemsByTypeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getItemsByType.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::getItemsByType
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:76
 * @route '/inventory/adjustments/items'
 */
        getItemsByTypeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getItemsByType.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::getItemsByType
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:76
 * @route '/inventory/adjustments/items'
 */
        getItemsByTypeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getItemsByType.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getItemsByType.form = getItemsByTypeForm
/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::globalSearch
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:90
 * @route '/inventory/search'
 */
export const globalSearch = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: globalSearch.url(options),
    method: 'get',
})

globalSearch.definition = {
    methods: ["get","head"],
    url: '/inventory/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::globalSearch
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:90
 * @route '/inventory/search'
 */
globalSearch.url = (options?: RouteQueryOptions) => {
    return globalSearch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::globalSearch
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:90
 * @route '/inventory/search'
 */
globalSearch.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: globalSearch.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::globalSearch
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:90
 * @route '/inventory/search'
 */
globalSearch.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: globalSearch.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::globalSearch
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:90
 * @route '/inventory/search'
 */
    const globalSearchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: globalSearch.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::globalSearch
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:90
 * @route '/inventory/search'
 */
        globalSearchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: globalSearch.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\StockAdjustmentController::globalSearch
 * @see app/Http/Controllers/Inventory/StockAdjustmentController.php:90
 * @route '/inventory/search'
 */
        globalSearchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: globalSearch.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    globalSearch.form = globalSearchForm
const StockAdjustmentController = { index, store, getItemsByType, globalSearch }

export default StockAdjustmentController