import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Inventory\LeatherController::index
 * @see app/Http/Controllers/Inventory/LeatherController.php:29
 * @route '/inventory/leather'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/inventory/leather',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::index
 * @see app/Http/Controllers/Inventory/LeatherController.php:29
 * @route '/inventory/leather'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::index
 * @see app/Http/Controllers/Inventory/LeatherController.php:29
 * @route '/inventory/leather'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\LeatherController::index
 * @see app/Http/Controllers/Inventory/LeatherController.php:29
 * @route '/inventory/leather'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::index
 * @see app/Http/Controllers/Inventory/LeatherController.php:29
 * @route '/inventory/leather'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::index
 * @see app/Http/Controllers/Inventory/LeatherController.php:29
 * @route '/inventory/leather'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\LeatherController::index
 * @see app/Http/Controllers/Inventory/LeatherController.php:29
 * @route '/inventory/leather'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Inventory\LeatherController::storeItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:159
 * @route '/inventory/leather/items'
 */
export const storeItem = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeItem.url(options),
    method: 'post',
})

storeItem.definition = {
    methods: ["post"],
    url: '/inventory/leather/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::storeItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:159
 * @route '/inventory/leather/items'
 */
storeItem.url = (options?: RouteQueryOptions) => {
    return storeItem.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::storeItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:159
 * @route '/inventory/leather/items'
 */
storeItem.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeItem.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::storeItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:159
 * @route '/inventory/leather/items'
 */
    const storeItemForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeItem.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::storeItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:159
 * @route '/inventory/leather/items'
 */
        storeItemForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeItem.url(options),
            method: 'post',
        })
    
    storeItem.form = storeItemForm
/**
* @see \App\Http\Controllers\Inventory\LeatherController::updateItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:169
 * @route '/inventory/leather/items/{item}'
 */
export const updateItem = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

updateItem.definition = {
    methods: ["put"],
    url: '/inventory/leather/items/{item}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::updateItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:169
 * @route '/inventory/leather/items/{item}'
 */
updateItem.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return updateItem.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::updateItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:169
 * @route '/inventory/leather/items/{item}'
 */
updateItem.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::updateItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:169
 * @route '/inventory/leather/items/{item}'
 */
    const updateItemForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateItem.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::updateItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:169
 * @route '/inventory/leather/items/{item}'
 */
        updateItemForm.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateItem.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateItem.form = updateItemForm
/**
* @see \App\Http\Controllers\Inventory\LeatherController::destroyItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:179
 * @route '/inventory/leather/items/{item}'
 */
export const destroyItem = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyItem.url(args, options),
    method: 'delete',
})

destroyItem.definition = {
    methods: ["delete"],
    url: '/inventory/leather/items/{item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::destroyItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:179
 * @route '/inventory/leather/items/{item}'
 */
destroyItem.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return destroyItem.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::destroyItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:179
 * @route '/inventory/leather/items/{item}'
 */
destroyItem.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyItem.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::destroyItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:179
 * @route '/inventory/leather/items/{item}'
 */
    const destroyItemForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyItem.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::destroyItem
 * @see app/Http/Controllers/Inventory/LeatherController.php:179
 * @route '/inventory/leather/items/{item}'
 */
        destroyItemForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyItem.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyItem.form = destroyItemForm
/**
* @see \App\Http\Controllers\Inventory\LeatherController::storePurchase
 * @see app/Http/Controllers/Inventory/LeatherController.php:192
 * @route '/inventory/leather/purchases'
 */
export const storePurchase = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePurchase.url(options),
    method: 'post',
})

storePurchase.definition = {
    methods: ["post"],
    url: '/inventory/leather/purchases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::storePurchase
 * @see app/Http/Controllers/Inventory/LeatherController.php:192
 * @route '/inventory/leather/purchases'
 */
storePurchase.url = (options?: RouteQueryOptions) => {
    return storePurchase.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::storePurchase
 * @see app/Http/Controllers/Inventory/LeatherController.php:192
 * @route '/inventory/leather/purchases'
 */
storePurchase.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePurchase.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::storePurchase
 * @see app/Http/Controllers/Inventory/LeatherController.php:192
 * @route '/inventory/leather/purchases'
 */
    const storePurchaseForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storePurchase.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::storePurchase
 * @see app/Http/Controllers/Inventory/LeatherController.php:192
 * @route '/inventory/leather/purchases'
 */
        storePurchaseForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storePurchase.url(options),
            method: 'post',
        })
    
    storePurchase.form = storePurchaseForm
/**
* @see \App\Http\Controllers\Inventory\LeatherController::storeConsumption
 * @see app/Http/Controllers/Inventory/LeatherController.php:206
 * @route '/inventory/leather/consumptions'
 */
export const storeConsumption = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeConsumption.url(options),
    method: 'post',
})

storeConsumption.definition = {
    methods: ["post"],
    url: '/inventory/leather/consumptions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::storeConsumption
 * @see app/Http/Controllers/Inventory/LeatherController.php:206
 * @route '/inventory/leather/consumptions'
 */
storeConsumption.url = (options?: RouteQueryOptions) => {
    return storeConsumption.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::storeConsumption
 * @see app/Http/Controllers/Inventory/LeatherController.php:206
 * @route '/inventory/leather/consumptions'
 */
storeConsumption.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeConsumption.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::storeConsumption
 * @see app/Http/Controllers/Inventory/LeatherController.php:206
 * @route '/inventory/leather/consumptions'
 */
    const storeConsumptionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeConsumption.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::storeConsumption
 * @see app/Http/Controllers/Inventory/LeatherController.php:206
 * @route '/inventory/leather/consumptions'
 */
        storeConsumptionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeConsumption.url(options),
            method: 'post',
        })
    
    storeConsumption.form = storeConsumptionForm
/**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjust-stock'
 */
const adjustStocka7e117cdeb2d3cf676354af3dc34e46f = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStocka7e117cdeb2d3cf676354af3dc34e46f.url(options),
    method: 'post',
})

adjustStocka7e117cdeb2d3cf676354af3dc34e46f.definition = {
    methods: ["post"],
    url: '/inventory/leather/adjust-stock',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjust-stock'
 */
adjustStocka7e117cdeb2d3cf676354af3dc34e46f.url = (options?: RouteQueryOptions) => {
    return adjustStocka7e117cdeb2d3cf676354af3dc34e46f.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjust-stock'
 */
adjustStocka7e117cdeb2d3cf676354af3dc34e46f.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStocka7e117cdeb2d3cf676354af3dc34e46f.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjust-stock'
 */
    const adjustStocka7e117cdeb2d3cf676354af3dc34e46fForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adjustStocka7e117cdeb2d3cf676354af3dc34e46f.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjust-stock'
 */
        adjustStocka7e117cdeb2d3cf676354af3dc34e46fForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adjustStocka7e117cdeb2d3cf676354af3dc34e46f.url(options),
            method: 'post',
        })
    
    adjustStocka7e117cdeb2d3cf676354af3dc34e46f.form = adjustStocka7e117cdeb2d3cf676354af3dc34e46fForm
    /**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjustments'
 */
const adjustStock7768ead3aed6b2d6c62566ab28eb739d = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock7768ead3aed6b2d6c62566ab28eb739d.url(options),
    method: 'post',
})

adjustStock7768ead3aed6b2d6c62566ab28eb739d.definition = {
    methods: ["post"],
    url: '/inventory/leather/adjustments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjustments'
 */
adjustStock7768ead3aed6b2d6c62566ab28eb739d.url = (options?: RouteQueryOptions) => {
    return adjustStock7768ead3aed6b2d6c62566ab28eb739d.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjustments'
 */
adjustStock7768ead3aed6b2d6c62566ab28eb739d.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: adjustStock7768ead3aed6b2d6c62566ab28eb739d.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjustments'
 */
    const adjustStock7768ead3aed6b2d6c62566ab28eb739dForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: adjustStock7768ead3aed6b2d6c62566ab28eb739d.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::adjustStock
 * @see app/Http/Controllers/Inventory/LeatherController.php:220
 * @route '/inventory/leather/adjustments'
 */
        adjustStock7768ead3aed6b2d6c62566ab28eb739dForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: adjustStock7768ead3aed6b2d6c62566ab28eb739d.url(options),
            method: 'post',
        })
    
    adjustStock7768ead3aed6b2d6c62566ab28eb739d.form = adjustStock7768ead3aed6b2d6c62566ab28eb739dForm

/**
* Multiple routes resolve to \App\Http\Controllers\Inventory\LeatherController::adjustStock, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `adjustStock['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const adjustStock = {
    '/inventory/leather/adjust-stock': adjustStocka7e117cdeb2d3cf676354af3dc34e46f,
    '/inventory/leather/adjustments': adjustStock7768ead3aed6b2d6c62566ab28eb739d,
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/items/{item}/movements'
 */
const movementsa161df2de89ba8f5238e74ab3e70d021 = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movementsa161df2de89ba8f5238e74ab3e70d021.url(args, options),
    method: 'get',
})

movementsa161df2de89ba8f5238e74ab3e70d021.definition = {
    methods: ["get","head"],
    url: '/inventory/leather/items/{item}/movements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/items/{item}/movements'
 */
movementsa161df2de89ba8f5238e74ab3e70d021.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return movementsa161df2de89ba8f5238e74ab3e70d021.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/items/{item}/movements'
 */
movementsa161df2de89ba8f5238e74ab3e70d021.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movementsa161df2de89ba8f5238e74ab3e70d021.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/items/{item}/movements'
 */
movementsa161df2de89ba8f5238e74ab3e70d021.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: movementsa161df2de89ba8f5238e74ab3e70d021.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/items/{item}/movements'
 */
    const movementsa161df2de89ba8f5238e74ab3e70d021Form = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: movementsa161df2de89ba8f5238e74ab3e70d021.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/items/{item}/movements'
 */
        movementsa161df2de89ba8f5238e74ab3e70d021Form.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movementsa161df2de89ba8f5238e74ab3e70d021.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/items/{item}/movements'
 */
        movementsa161df2de89ba8f5238e74ab3e70d021Form.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movementsa161df2de89ba8f5238e74ab3e70d021.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    movementsa161df2de89ba8f5238e74ab3e70d021.form = movementsa161df2de89ba8f5238e74ab3e70d021Form
    /**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/{item}/movements'
 */
const movements7b10a175a4325547a3bd7cb022b3cb81 = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements7b10a175a4325547a3bd7cb022b3cb81.url(args, options),
    method: 'get',
})

movements7b10a175a4325547a3bd7cb022b3cb81.definition = {
    methods: ["get","head"],
    url: '/inventory/leather/{item}/movements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/{item}/movements'
 */
movements7b10a175a4325547a3bd7cb022b3cb81.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return movements7b10a175a4325547a3bd7cb022b3cb81.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/{item}/movements'
 */
movements7b10a175a4325547a3bd7cb022b3cb81.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: movements7b10a175a4325547a3bd7cb022b3cb81.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/{item}/movements'
 */
movements7b10a175a4325547a3bd7cb022b3cb81.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: movements7b10a175a4325547a3bd7cb022b3cb81.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/{item}/movements'
 */
    const movements7b10a175a4325547a3bd7cb022b3cb81Form = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: movements7b10a175a4325547a3bd7cb022b3cb81.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/{item}/movements'
 */
        movements7b10a175a4325547a3bd7cb022b3cb81Form.get = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movements7b10a175a4325547a3bd7cb022b3cb81.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Inventory\LeatherController::movements
 * @see app/Http/Controllers/Inventory/LeatherController.php:244
 * @route '/inventory/leather/{item}/movements'
 */
        movements7b10a175a4325547a3bd7cb022b3cb81Form.head = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: movements7b10a175a4325547a3bd7cb022b3cb81.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    movements7b10a175a4325547a3bd7cb022b3cb81.form = movements7b10a175a4325547a3bd7cb022b3cb81Form

/**
* Multiple routes resolve to \App\Http\Controllers\Inventory\LeatherController::movements, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `movements['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const movements = {
    '/inventory/leather/items/{item}/movements': movementsa161df2de89ba8f5238e74ab3e70d021,
    '/inventory/leather/{item}/movements': movements7b10a175a4325547a3bd7cb022b3cb81,
}

const LeatherController = { index, storeItem, updateItem, destroyItem, storePurchase, storeConsumption, adjustStock, movements }

export default LeatherController