import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Reports\ProfitLossController::index
 * @see app/Http/Controllers/Reports/ProfitLossController.php:25
 * @route '/reports/profit-loss'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/reports/profit-loss',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ProfitLossController::index
 * @see app/Http/Controllers/Reports/ProfitLossController.php:25
 * @route '/reports/profit-loss'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ProfitLossController::index
 * @see app/Http/Controllers/Reports/ProfitLossController.php:25
 * @route '/reports/profit-loss'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ProfitLossController::index
 * @see app/Http/Controllers/Reports/ProfitLossController.php:25
 * @route '/reports/profit-loss'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ProfitLossController::index
 * @see app/Http/Controllers/Reports/ProfitLossController.php:25
 * @route '/reports/profit-loss'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ProfitLossController::index
 * @see app/Http/Controllers/Reports/ProfitLossController.php:25
 * @route '/reports/profit-loss'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ProfitLossController::index
 * @see app/Http/Controllers/Reports/ProfitLossController.php:25
 * @route '/reports/profit-loss'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Reports\ProfitLossController::drilldown
 * @see app/Http/Controllers/Reports/ProfitLossController.php:75
 * @route '/reports/profit-loss/drilldown'
 */
export const drilldown = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: drilldown.url(options),
    method: 'get',
})

drilldown.definition = {
    methods: ["get","head"],
    url: '/reports/profit-loss/drilldown',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ProfitLossController::drilldown
 * @see app/Http/Controllers/Reports/ProfitLossController.php:75
 * @route '/reports/profit-loss/drilldown'
 */
drilldown.url = (options?: RouteQueryOptions) => {
    return drilldown.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ProfitLossController::drilldown
 * @see app/Http/Controllers/Reports/ProfitLossController.php:75
 * @route '/reports/profit-loss/drilldown'
 */
drilldown.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: drilldown.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ProfitLossController::drilldown
 * @see app/Http/Controllers/Reports/ProfitLossController.php:75
 * @route '/reports/profit-loss/drilldown'
 */
drilldown.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: drilldown.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ProfitLossController::drilldown
 * @see app/Http/Controllers/Reports/ProfitLossController.php:75
 * @route '/reports/profit-loss/drilldown'
 */
    const drilldownForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: drilldown.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ProfitLossController::drilldown
 * @see app/Http/Controllers/Reports/ProfitLossController.php:75
 * @route '/reports/profit-loss/drilldown'
 */
        drilldownForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: drilldown.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ProfitLossController::drilldown
 * @see app/Http/Controllers/Reports/ProfitLossController.php:75
 * @route '/reports/profit-loss/drilldown'
 */
        drilldownForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: drilldown.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    drilldown.form = drilldownForm
/**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportExcel
 * @see app/Http/Controllers/Reports/ProfitLossController.php:98
 * @route '/reports/profit-loss/export/excel'
 */
export const exportExcel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportExcel.url(options),
    method: 'get',
})

exportExcel.definition = {
    methods: ["get","head"],
    url: '/reports/profit-loss/export/excel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportExcel
 * @see app/Http/Controllers/Reports/ProfitLossController.php:98
 * @route '/reports/profit-loss/export/excel'
 */
exportExcel.url = (options?: RouteQueryOptions) => {
    return exportExcel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportExcel
 * @see app/Http/Controllers/Reports/ProfitLossController.php:98
 * @route '/reports/profit-loss/export/excel'
 */
exportExcel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportExcel.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportExcel
 * @see app/Http/Controllers/Reports/ProfitLossController.php:98
 * @route '/reports/profit-loss/export/excel'
 */
exportExcel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportExcel.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportExcel
 * @see app/Http/Controllers/Reports/ProfitLossController.php:98
 * @route '/reports/profit-loss/export/excel'
 */
    const exportExcelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportExcel.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportExcel
 * @see app/Http/Controllers/Reports/ProfitLossController.php:98
 * @route '/reports/profit-loss/export/excel'
 */
        exportExcelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportExcel.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportExcel
 * @see app/Http/Controllers/Reports/ProfitLossController.php:98
 * @route '/reports/profit-loss/export/excel'
 */
        exportExcelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportExcel.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportExcel.form = exportExcelForm
/**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportPdf
 * @see app/Http/Controllers/Reports/ProfitLossController.php:128
 * @route '/reports/profit-loss/export/pdf'
 */
export const exportPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})

exportPdf.definition = {
    methods: ["get","head"],
    url: '/reports/profit-loss/export/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportPdf
 * @see app/Http/Controllers/Reports/ProfitLossController.php:128
 * @route '/reports/profit-loss/export/pdf'
 */
exportPdf.url = (options?: RouteQueryOptions) => {
    return exportPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportPdf
 * @see app/Http/Controllers/Reports/ProfitLossController.php:128
 * @route '/reports/profit-loss/export/pdf'
 */
exportPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportPdf
 * @see app/Http/Controllers/Reports/ProfitLossController.php:128
 * @route '/reports/profit-loss/export/pdf'
 */
exportPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportPdf.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportPdf
 * @see app/Http/Controllers/Reports/ProfitLossController.php:128
 * @route '/reports/profit-loss/export/pdf'
 */
    const exportPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportPdf.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportPdf
 * @see app/Http/Controllers/Reports/ProfitLossController.php:128
 * @route '/reports/profit-loss/export/pdf'
 */
        exportPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportPdf.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\ProfitLossController::exportPdf
 * @see app/Http/Controllers/Reports/ProfitLossController.php:128
 * @route '/reports/profit-loss/export/pdf'
 */
        exportPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportPdf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportPdf.form = exportPdfForm
const ProfitLossController = { index, drilldown, exportExcel, exportPdf }

export default ProfitLossController