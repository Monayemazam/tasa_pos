import SalesReportController from './SalesReportController'
import ProfitLossController from './ProfitLossController'
const Reports = {
    SalesReportController: Object.assign(SalesReportController, SalesReportController),
ProfitLossController: Object.assign(ProfitLossController, ProfitLossController),
}

export default Reports