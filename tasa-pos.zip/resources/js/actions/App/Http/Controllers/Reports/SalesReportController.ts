import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Reports\SalesReportController::index
 * @see app/Http/Controllers/Reports/SalesReportController.php:26
 * @route '/reports/sales'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/reports/sales',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\SalesReportController::index
 * @see app/Http/Controllers/Reports/SalesReportController.php:26
 * @route '/reports/sales'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\SalesReportController::index
 * @see app/Http/Controllers/Reports/SalesReportController.php:26
 * @route '/reports/sales'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\SalesReportController::index
 * @see app/Http/Controllers/Reports/SalesReportController.php:26
 * @route '/reports/sales'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\SalesReportController::index
 * @see app/Http/Controllers/Reports/SalesReportController.php:26
 * @route '/reports/sales'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\SalesReportController::index
 * @see app/Http/Controllers/Reports/SalesReportController.php:26
 * @route '/reports/sales'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\SalesReportController::index
 * @see app/Http/Controllers/Reports/SalesReportController.php:26
 * @route '/reports/sales'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Reports\SalesReportController::drilldown
 * @see app/Http/Controllers/Reports/SalesReportController.php:69
 * @route '/reports/sales/drilldown'
 */
export const drilldown = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: drilldown.url(options),
    method: 'get',
})

drilldown.definition = {
    methods: ["get","head"],
    url: '/reports/sales/drilldown',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\SalesReportController::drilldown
 * @see app/Http/Controllers/Reports/SalesReportController.php:69
 * @route '/reports/sales/drilldown'
 */
drilldown.url = (options?: RouteQueryOptions) => {
    return drilldown.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\SalesReportController::drilldown
 * @see app/Http/Controllers/Reports/SalesReportController.php:69
 * @route '/reports/sales/drilldown'
 */
drilldown.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: drilldown.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\SalesReportController::drilldown
 * @see app/Http/Controllers/Reports/SalesReportController.php:69
 * @route '/reports/sales/drilldown'
 */
drilldown.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: drilldown.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\SalesReportController::drilldown
 * @see app/Http/Controllers/Reports/SalesReportController.php:69
 * @route '/reports/sales/drilldown'
 */
    const drilldownForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: drilldown.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\SalesReportController::drilldown
 * @see app/Http/Controllers/Reports/SalesReportController.php:69
 * @route '/reports/sales/drilldown'
 */
        drilldownForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: drilldown.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\SalesReportController::drilldown
 * @see app/Http/Controllers/Reports/SalesReportController.php:69
 * @route '/reports/sales/drilldown'
 */
        drilldownForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: drilldown.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    drilldown.form = drilldownForm
/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportCsv
 * @see app/Http/Controllers/Reports/SalesReportController.php:89
 * @route '/reports/sales/export/csv'
 */
export const exportCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})

exportCsv.definition = {
    methods: ["get","head"],
    url: '/reports/sales/export/csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportCsv
 * @see app/Http/Controllers/Reports/SalesReportController.php:89
 * @route '/reports/sales/export/csv'
 */
exportCsv.url = (options?: RouteQueryOptions) => {
    return exportCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportCsv
 * @see app/Http/Controllers/Reports/SalesReportController.php:89
 * @route '/reports/sales/export/csv'
 */
exportCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportCsv
 * @see app/Http/Controllers/Reports/SalesReportController.php:89
 * @route '/reports/sales/export/csv'
 */
exportCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportCsv.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\SalesReportController::exportCsv
 * @see app/Http/Controllers/Reports/SalesReportController.php:89
 * @route '/reports/sales/export/csv'
 */
    const exportCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportCsv.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\SalesReportController::exportCsv
 * @see app/Http/Controllers/Reports/SalesReportController.php:89
 * @route '/reports/sales/export/csv'
 */
        exportCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\SalesReportController::exportCsv
 * @see app/Http/Controllers/Reports/SalesReportController.php:89
 * @route '/reports/sales/export/csv'
 */
        exportCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportCsv.form = exportCsvForm
/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportExcel
 * @see app/Http/Controllers/Reports/SalesReportController.php:114
 * @route '/reports/sales/export/excel'
 */
export const exportExcel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportExcel.url(options),
    method: 'get',
})

exportExcel.definition = {
    methods: ["get","head"],
    url: '/reports/sales/export/excel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportExcel
 * @see app/Http/Controllers/Reports/SalesReportController.php:114
 * @route '/reports/sales/export/excel'
 */
exportExcel.url = (options?: RouteQueryOptions) => {
    return exportExcel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportExcel
 * @see app/Http/Controllers/Reports/SalesReportController.php:114
 * @route '/reports/sales/export/excel'
 */
exportExcel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportExcel.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportExcel
 * @see app/Http/Controllers/Reports/SalesReportController.php:114
 * @route '/reports/sales/export/excel'
 */
exportExcel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportExcel.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\SalesReportController::exportExcel
 * @see app/Http/Controllers/Reports/SalesReportController.php:114
 * @route '/reports/sales/export/excel'
 */
    const exportExcelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportExcel.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\SalesReportController::exportExcel
 * @see app/Http/Controllers/Reports/SalesReportController.php:114
 * @route '/reports/sales/export/excel'
 */
        exportExcelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportExcel.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\SalesReportController::exportExcel
 * @see app/Http/Controllers/Reports/SalesReportController.php:114
 * @route '/reports/sales/export/excel'
 */
        exportExcelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportExcel.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportExcel.form = exportExcelForm
/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportPdf
 * @see app/Http/Controllers/Reports/SalesReportController.php:141
 * @route '/reports/sales/export/pdf'
 */
export const exportPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})

exportPdf.definition = {
    methods: ["get","head"],
    url: '/reports/sales/export/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportPdf
 * @see app/Http/Controllers/Reports/SalesReportController.php:141
 * @route '/reports/sales/export/pdf'
 */
exportPdf.url = (options?: RouteQueryOptions) => {
    return exportPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportPdf
 * @see app/Http/Controllers/Reports/SalesReportController.php:141
 * @route '/reports/sales/export/pdf'
 */
exportPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Reports\SalesReportController::exportPdf
 * @see app/Http/Controllers/Reports/SalesReportController.php:141
 * @route '/reports/sales/export/pdf'
 */
exportPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportPdf.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Reports\SalesReportController::exportPdf
 * @see app/Http/Controllers/Reports/SalesReportController.php:141
 * @route '/reports/sales/export/pdf'
 */
    const exportPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportPdf.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Reports\SalesReportController::exportPdf
 * @see app/Http/Controllers/Reports/SalesReportController.php:141
 * @route '/reports/sales/export/pdf'
 */
        exportPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportPdf.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Reports\SalesReportController::exportPdf
 * @see app/Http/Controllers/Reports/SalesReportController.php:141
 * @route '/reports/sales/export/pdf'
 */
        exportPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportPdf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportPdf.form = exportPdfForm
const SalesReportController = { index, drilldown, exportCsv, exportExcel, exportPdf }

export default SalesReportController