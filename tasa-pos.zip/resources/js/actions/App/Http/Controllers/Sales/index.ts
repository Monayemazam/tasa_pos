import PosController from './PosController'
import CustomerController from './CustomerController'
import SalePaymentController from './SalePaymentController'
import InvoiceController from './InvoiceController'
import CourierOrderController from './CourierOrderController'
const Sales = {
    PosController: Object.assign(PosController, PosController),
CustomerController: Object.assign(CustomerController, CustomerController),
SalePaymentController: Object.assign(SalePaymentController, SalePaymentController),
InvoiceController: Object.assign(InvoiceController, InvoiceController),
CourierOrderController: Object.assign(CourierOrderController, CourierOrderController),
}

export default Sales