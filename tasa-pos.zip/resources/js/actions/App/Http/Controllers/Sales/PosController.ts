import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Sales\PosController::create
 * @see app/Http/Controllers/Sales/PosController.php:30
 * @route '/sales/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/sales/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\PosController::create
 * @see app/Http/Controllers/Sales/PosController.php:30
 * @route '/sales/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\PosController::create
 * @see app/Http/Controllers/Sales/PosController.php:30
 * @route '/sales/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\PosController::create
 * @see app/Http/Controllers/Sales/PosController.php:30
 * @route '/sales/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\PosController::create
 * @see app/Http/Controllers/Sales/PosController.php:30
 * @route '/sales/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\PosController::create
 * @see app/Http/Controllers/Sales/PosController.php:30
 * @route '/sales/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\PosController::create
 * @see app/Http/Controllers/Sales/PosController.php:30
 * @route '/sales/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Sales\PosController::store
 * @see app/Http/Controllers/Sales/PosController.php:102
 * @route '/sales'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/sales',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sales\PosController::store
 * @see app/Http/Controllers/Sales/PosController.php:102
 * @route '/sales'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\PosController::store
 * @see app/Http/Controllers/Sales/PosController.php:102
 * @route '/sales'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sales\PosController::store
 * @see app/Http/Controllers/Sales/PosController.php:102
 * @route '/sales'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\PosController::store
 * @see app/Http/Controllers/Sales/PosController.php:102
 * @route '/sales'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Sales\PosController::customerLookup
 * @see app/Http/Controllers/Sales/PosController.php:119
 * @route '/sales/customers/lookup'
 */
export const customerLookup = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customerLookup.url(options),
    method: 'get',
})

customerLookup.definition = {
    methods: ["get","head"],
    url: '/sales/customers/lookup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\PosController::customerLookup
 * @see app/Http/Controllers/Sales/PosController.php:119
 * @route '/sales/customers/lookup'
 */
customerLookup.url = (options?: RouteQueryOptions) => {
    return customerLookup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\PosController::customerLookup
 * @see app/Http/Controllers/Sales/PosController.php:119
 * @route '/sales/customers/lookup'
 */
customerLookup.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customerLookup.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\PosController::customerLookup
 * @see app/Http/Controllers/Sales/PosController.php:119
 * @route '/sales/customers/lookup'
 */
customerLookup.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: customerLookup.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\PosController::customerLookup
 * @see app/Http/Controllers/Sales/PosController.php:119
 * @route '/sales/customers/lookup'
 */
    const customerLookupForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: customerLookup.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\PosController::customerLookup
 * @see app/Http/Controllers/Sales/PosController.php:119
 * @route '/sales/customers/lookup'
 */
        customerLookupForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: customerLookup.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\PosController::customerLookup
 * @see app/Http/Controllers/Sales/PosController.php:119
 * @route '/sales/customers/lookup'
 */
        customerLookupForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: customerLookup.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    customerLookup.form = customerLookupForm
/**
* @see \App\Http\Controllers\Sales\PosController::zones
 * @see app/Http/Controllers/Sales/PosController.php:144
 * @route '/sales/courier/zones'
 */
export const zones = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: zones.url(options),
    method: 'get',
})

zones.definition = {
    methods: ["get","head"],
    url: '/sales/courier/zones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\PosController::zones
 * @see app/Http/Controllers/Sales/PosController.php:144
 * @route '/sales/courier/zones'
 */
zones.url = (options?: RouteQueryOptions) => {
    return zones.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\PosController::zones
 * @see app/Http/Controllers/Sales/PosController.php:144
 * @route '/sales/courier/zones'
 */
zones.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: zones.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\PosController::zones
 * @see app/Http/Controllers/Sales/PosController.php:144
 * @route '/sales/courier/zones'
 */
zones.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: zones.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\PosController::zones
 * @see app/Http/Controllers/Sales/PosController.php:144
 * @route '/sales/courier/zones'
 */
    const zonesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: zones.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\PosController::zones
 * @see app/Http/Controllers/Sales/PosController.php:144
 * @route '/sales/courier/zones'
 */
        zonesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: zones.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\PosController::zones
 * @see app/Http/Controllers/Sales/PosController.php:144
 * @route '/sales/courier/zones'
 */
        zonesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: zones.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    zones.form = zonesForm
/**
* @see \App\Http\Controllers\Sales\PosController::areas
 * @see app/Http/Controllers/Sales/PosController.php:157
 * @route '/sales/courier/areas'
 */
export const areas = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: areas.url(options),
    method: 'get',
})

areas.definition = {
    methods: ["get","head"],
    url: '/sales/courier/areas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\PosController::areas
 * @see app/Http/Controllers/Sales/PosController.php:157
 * @route '/sales/courier/areas'
 */
areas.url = (options?: RouteQueryOptions) => {
    return areas.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\PosController::areas
 * @see app/Http/Controllers/Sales/PosController.php:157
 * @route '/sales/courier/areas'
 */
areas.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: areas.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\PosController::areas
 * @see app/Http/Controllers/Sales/PosController.php:157
 * @route '/sales/courier/areas'
 */
areas.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: areas.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\PosController::areas
 * @see app/Http/Controllers/Sales/PosController.php:157
 * @route '/sales/courier/areas'
 */
    const areasForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: areas.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\PosController::areas
 * @see app/Http/Controllers/Sales/PosController.php:157
 * @route '/sales/courier/areas'
 */
        areasForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: areas.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\PosController::areas
 * @see app/Http/Controllers/Sales/PosController.php:157
 * @route '/sales/courier/areas'
 */
        areasForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: areas.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    areas.form = areasForm
/**
* @see \App\Http\Controllers\Sales\PosController::successRate
 * @see app/Http/Controllers/Sales/PosController.php:170
 * @route '/sales/courier/success-rate'
 */
export const successRate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: successRate.url(options),
    method: 'get',
})

successRate.definition = {
    methods: ["get","head"],
    url: '/sales/courier/success-rate',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\PosController::successRate
 * @see app/Http/Controllers/Sales/PosController.php:170
 * @route '/sales/courier/success-rate'
 */
successRate.url = (options?: RouteQueryOptions) => {
    return successRate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\PosController::successRate
 * @see app/Http/Controllers/Sales/PosController.php:170
 * @route '/sales/courier/success-rate'
 */
successRate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: successRate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\PosController::successRate
 * @see app/Http/Controllers/Sales/PosController.php:170
 * @route '/sales/courier/success-rate'
 */
successRate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: successRate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\PosController::successRate
 * @see app/Http/Controllers/Sales/PosController.php:170
 * @route '/sales/courier/success-rate'
 */
    const successRateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: successRate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\PosController::successRate
 * @see app/Http/Controllers/Sales/PosController.php:170
 * @route '/sales/courier/success-rate'
 */
        successRateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: successRate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\PosController::successRate
 * @see app/Http/Controllers/Sales/PosController.php:170
 * @route '/sales/courier/success-rate'
 */
        successRateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: successRate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    successRate.form = successRateForm
const PosController = { create, store, customerLookup, zones, areas, successRate }

export default PosController