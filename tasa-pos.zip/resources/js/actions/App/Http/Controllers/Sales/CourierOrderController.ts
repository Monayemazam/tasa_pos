import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Sales\CourierOrderController::index
 * @see app/Http/Controllers/Sales/CourierOrderController.php:26
 * @route '/sales/courier'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/sales/courier',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::index
 * @see app/Http/Controllers/Sales/CourierOrderController.php:26
 * @route '/sales/courier'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::index
 * @see app/Http/Controllers/Sales/CourierOrderController.php:26
 * @route '/sales/courier'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\CourierOrderController::index
 * @see app/Http/Controllers/Sales/CourierOrderController.php:26
 * @route '/sales/courier'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\CourierOrderController::index
 * @see app/Http/Controllers/Sales/CourierOrderController.php:26
 * @route '/sales/courier'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\CourierOrderController::index
 * @see app/Http/Controllers/Sales/CourierOrderController.php:26
 * @route '/sales/courier'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\CourierOrderController::index
 * @see app/Http/Controllers/Sales/CourierOrderController.php:26
 * @route '/sales/courier'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Sales\CourierOrderController::retry
 * @see app/Http/Controllers/Sales/CourierOrderController.php:130
 * @route '/sales/courier/{courierOrder}/retry'
 */
export const retry = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retry.url(args, options),
    method: 'post',
})

retry.definition = {
    methods: ["post"],
    url: '/sales/courier/{courierOrder}/retry',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::retry
 * @see app/Http/Controllers/Sales/CourierOrderController.php:130
 * @route '/sales/courier/{courierOrder}/retry'
 */
retry.url = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courierOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { courierOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    courierOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        courierOrder: typeof args.courierOrder === 'object'
                ? args.courierOrder.id
                : args.courierOrder,
                }

    return retry.definition.url
            .replace('{courierOrder}', parsedArgs.courierOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::retry
 * @see app/Http/Controllers/Sales/CourierOrderController.php:130
 * @route '/sales/courier/{courierOrder}/retry'
 */
retry.post = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retry.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sales\CourierOrderController::retry
 * @see app/Http/Controllers/Sales/CourierOrderController.php:130
 * @route '/sales/courier/{courierOrder}/retry'
 */
    const retryForm = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: retry.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\CourierOrderController::retry
 * @see app/Http/Controllers/Sales/CourierOrderController.php:130
 * @route '/sales/courier/{courierOrder}/retry'
 */
        retryForm.post = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: retry.url(args, options),
            method: 'post',
        })
    
    retry.form = retryForm
/**
* @see \App\Http\Controllers\Sales\CourierOrderController::sync
 * @see app/Http/Controllers/Sales/CourierOrderController.php:153
 * @route '/sales/courier/{courierOrder}/sync'
 */
export const sync = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/sales/courier/{courierOrder}/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::sync
 * @see app/Http/Controllers/Sales/CourierOrderController.php:153
 * @route '/sales/courier/{courierOrder}/sync'
 */
sync.url = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courierOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { courierOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    courierOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        courierOrder: typeof args.courierOrder === 'object'
                ? args.courierOrder.id
                : args.courierOrder,
                }

    return sync.definition.url
            .replace('{courierOrder}', parsedArgs.courierOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::sync
 * @see app/Http/Controllers/Sales/CourierOrderController.php:153
 * @route '/sales/courier/{courierOrder}/sync'
 */
sync.post = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sales\CourierOrderController::sync
 * @see app/Http/Controllers/Sales/CourierOrderController.php:153
 * @route '/sales/courier/{courierOrder}/sync'
 */
    const syncForm = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sync.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\CourierOrderController::sync
 * @see app/Http/Controllers/Sales/CourierOrderController.php:153
 * @route '/sales/courier/{courierOrder}/sync'
 */
        syncForm.post = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sync.url(args, options),
            method: 'post',
        })
    
    sync.form = syncForm
/**
* @see \App\Http\Controllers\Sales\CourierOrderController::settleCod
 * @see app/Http/Controllers/Sales/CourierOrderController.php:173
 * @route '/sales/courier/{courierOrder}/settle-cod'
 */
export const settleCod = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: settleCod.url(args, options),
    method: 'post',
})

settleCod.definition = {
    methods: ["post"],
    url: '/sales/courier/{courierOrder}/settle-cod',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::settleCod
 * @see app/Http/Controllers/Sales/CourierOrderController.php:173
 * @route '/sales/courier/{courierOrder}/settle-cod'
 */
settleCod.url = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courierOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { courierOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    courierOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        courierOrder: typeof args.courierOrder === 'object'
                ? args.courierOrder.id
                : args.courierOrder,
                }

    return settleCod.definition.url
            .replace('{courierOrder}', parsedArgs.courierOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::settleCod
 * @see app/Http/Controllers/Sales/CourierOrderController.php:173
 * @route '/sales/courier/{courierOrder}/settle-cod'
 */
settleCod.post = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: settleCod.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sales\CourierOrderController::settleCod
 * @see app/Http/Controllers/Sales/CourierOrderController.php:173
 * @route '/sales/courier/{courierOrder}/settle-cod'
 */
    const settleCodForm = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: settleCod.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\CourierOrderController::settleCod
 * @see app/Http/Controllers/Sales/CourierOrderController.php:173
 * @route '/sales/courier/{courierOrder}/settle-cod'
 */
        settleCodForm.post = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: settleCod.url(args, options),
            method: 'post',
        })
    
    settleCod.form = settleCodForm
/**
* @see \App\Http\Controllers\Sales\CourierOrderController::update
 * @see app/Http/Controllers/Sales/CourierOrderController.php:201
 * @route '/sales/courier/{courierOrder}'
 */
export const update = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/sales/courier/{courierOrder}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::update
 * @see app/Http/Controllers/Sales/CourierOrderController.php:201
 * @route '/sales/courier/{courierOrder}'
 */
update.url = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courierOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { courierOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    courierOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        courierOrder: typeof args.courierOrder === 'object'
                ? args.courierOrder.id
                : args.courierOrder,
                }

    return update.definition.url
            .replace('{courierOrder}', parsedArgs.courierOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::update
 * @see app/Http/Controllers/Sales/CourierOrderController.php:201
 * @route '/sales/courier/{courierOrder}'
 */
update.put = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Sales\CourierOrderController::update
 * @see app/Http/Controllers/Sales/CourierOrderController.php:201
 * @route '/sales/courier/{courierOrder}'
 */
    const updateForm = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\CourierOrderController::update
 * @see app/Http/Controllers/Sales/CourierOrderController.php:201
 * @route '/sales/courier/{courierOrder}'
 */
        updateForm.put = (args: { courierOrder: number | { id: number } } | [courierOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Sales\CourierOrderController::testConnection
 * @see app/Http/Controllers/Sales/CourierOrderController.php:189
 * @route '/sales/courier/test-connection'
 */
export const testConnection = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: testConnection.url(options),
    method: 'get',
})

testConnection.definition = {
    methods: ["get","head"],
    url: '/sales/courier/test-connection',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::testConnection
 * @see app/Http/Controllers/Sales/CourierOrderController.php:189
 * @route '/sales/courier/test-connection'
 */
testConnection.url = (options?: RouteQueryOptions) => {
    return testConnection.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\CourierOrderController::testConnection
 * @see app/Http/Controllers/Sales/CourierOrderController.php:189
 * @route '/sales/courier/test-connection'
 */
testConnection.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: testConnection.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\CourierOrderController::testConnection
 * @see app/Http/Controllers/Sales/CourierOrderController.php:189
 * @route '/sales/courier/test-connection'
 */
testConnection.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: testConnection.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\CourierOrderController::testConnection
 * @see app/Http/Controllers/Sales/CourierOrderController.php:189
 * @route '/sales/courier/test-connection'
 */
    const testConnectionForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: testConnection.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\CourierOrderController::testConnection
 * @see app/Http/Controllers/Sales/CourierOrderController.php:189
 * @route '/sales/courier/test-connection'
 */
        testConnectionForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: testConnection.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\CourierOrderController::testConnection
 * @see app/Http/Controllers/Sales/CourierOrderController.php:189
 * @route '/sales/courier/test-connection'
 */
        testConnectionForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: testConnection.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    testConnection.form = testConnectionForm
const CourierOrderController = { index, retry, sync, settleCod, update, testConnection }

export default CourierOrderController