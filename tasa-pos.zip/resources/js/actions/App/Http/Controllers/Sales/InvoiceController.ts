import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Sales\InvoiceController::index
 * @see app/Http/Controllers/Sales/InvoiceController.php:33
 * @route '/sales/invoices'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/sales/invoices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\InvoiceController::index
 * @see app/Http/Controllers/Sales/InvoiceController.php:33
 * @route '/sales/invoices'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\InvoiceController::index
 * @see app/Http/Controllers/Sales/InvoiceController.php:33
 * @route '/sales/invoices'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\InvoiceController::index
 * @see app/Http/Controllers/Sales/InvoiceController.php:33
 * @route '/sales/invoices'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\InvoiceController::index
 * @see app/Http/Controllers/Sales/InvoiceController.php:33
 * @route '/sales/invoices'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\InvoiceController::index
 * @see app/Http/Controllers/Sales/InvoiceController.php:33
 * @route '/sales/invoices'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\InvoiceController::index
 * @see app/Http/Controllers/Sales/InvoiceController.php:33
 * @route '/sales/invoices'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Sales\InvoiceController::show
 * @see app/Http/Controllers/Sales/InvoiceController.php:189
 * @route '/sales/invoices/{sale}'
 */
export const show = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/sales/invoices/{sale}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\InvoiceController::show
 * @see app/Http/Controllers/Sales/InvoiceController.php:189
 * @route '/sales/invoices/{sale}'
 */
show.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sale: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sale: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sale: typeof args.sale === 'object'
                ? args.sale.id
                : args.sale,
                }

    return show.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\InvoiceController::show
 * @see app/Http/Controllers/Sales/InvoiceController.php:189
 * @route '/sales/invoices/{sale}'
 */
show.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\InvoiceController::show
 * @see app/Http/Controllers/Sales/InvoiceController.php:189
 * @route '/sales/invoices/{sale}'
 */
show.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\InvoiceController::show
 * @see app/Http/Controllers/Sales/InvoiceController.php:189
 * @route '/sales/invoices/{sale}'
 */
    const showForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\InvoiceController::show
 * @see app/Http/Controllers/Sales/InvoiceController.php:189
 * @route '/sales/invoices/{sale}'
 */
        showForm.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\InvoiceController::show
 * @see app/Http/Controllers/Sales/InvoiceController.php:189
 * @route '/sales/invoices/{sale}'
 */
        showForm.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Sales\InvoiceController::items
 * @see app/Http/Controllers/Sales/InvoiceController.php:265
 * @route '/sales/invoices/{sale}/items'
 */
export const items = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: items.url(args, options),
    method: 'get',
})

items.definition = {
    methods: ["get","head"],
    url: '/sales/invoices/{sale}/items',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\InvoiceController::items
 * @see app/Http/Controllers/Sales/InvoiceController.php:265
 * @route '/sales/invoices/{sale}/items'
 */
items.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sale: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sale: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sale: typeof args.sale === 'object'
                ? args.sale.id
                : args.sale,
                }

    return items.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\InvoiceController::items
 * @see app/Http/Controllers/Sales/InvoiceController.php:265
 * @route '/sales/invoices/{sale}/items'
 */
items.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: items.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\InvoiceController::items
 * @see app/Http/Controllers/Sales/InvoiceController.php:265
 * @route '/sales/invoices/{sale}/items'
 */
items.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: items.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\InvoiceController::items
 * @see app/Http/Controllers/Sales/InvoiceController.php:265
 * @route '/sales/invoices/{sale}/items'
 */
    const itemsForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: items.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\InvoiceController::items
 * @see app/Http/Controllers/Sales/InvoiceController.php:265
 * @route '/sales/invoices/{sale}/items'
 */
        itemsForm.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: items.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\InvoiceController::items
 * @see app/Http/Controllers/Sales/InvoiceController.php:265
 * @route '/sales/invoices/{sale}/items'
 */
        itemsForm.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: items.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    items.form = itemsForm
/**
* @see \App\Http\Controllers\Sales\InvoiceController::addPayment
 * @see app/Http/Controllers/Sales/InvoiceController.php:210
 * @route '/sales/invoices/{sale}/payments'
 */
export const addPayment = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addPayment.url(args, options),
    method: 'post',
})

addPayment.definition = {
    methods: ["post"],
    url: '/sales/invoices/{sale}/payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sales\InvoiceController::addPayment
 * @see app/Http/Controllers/Sales/InvoiceController.php:210
 * @route '/sales/invoices/{sale}/payments'
 */
addPayment.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sale: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sale: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sale: typeof args.sale === 'object'
                ? args.sale.id
                : args.sale,
                }

    return addPayment.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\InvoiceController::addPayment
 * @see app/Http/Controllers/Sales/InvoiceController.php:210
 * @route '/sales/invoices/{sale}/payments'
 */
addPayment.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addPayment.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sales\InvoiceController::addPayment
 * @see app/Http/Controllers/Sales/InvoiceController.php:210
 * @route '/sales/invoices/{sale}/payments'
 */
    const addPaymentForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addPayment.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\InvoiceController::addPayment
 * @see app/Http/Controllers/Sales/InvoiceController.php:210
 * @route '/sales/invoices/{sale}/payments'
 */
        addPaymentForm.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addPayment.url(args, options),
            method: 'post',
        })
    
    addPayment.form = addPaymentForm
/**
* @see \App\Http\Controllers\Sales\InvoiceController::cancel
 * @see app/Http/Controllers/Sales/InvoiceController.php:222
 * @route '/sales/invoices/{sale}/cancel'
 */
export const cancel = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/sales/invoices/{sale}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sales\InvoiceController::cancel
 * @see app/Http/Controllers/Sales/InvoiceController.php:222
 * @route '/sales/invoices/{sale}/cancel'
 */
cancel.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sale: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sale: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sale: typeof args.sale === 'object'
                ? args.sale.id
                : args.sale,
                }

    return cancel.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\InvoiceController::cancel
 * @see app/Http/Controllers/Sales/InvoiceController.php:222
 * @route '/sales/invoices/{sale}/cancel'
 */
cancel.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sales\InvoiceController::cancel
 * @see app/Http/Controllers/Sales/InvoiceController.php:222
 * @route '/sales/invoices/{sale}/cancel'
 */
    const cancelForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\InvoiceController::cancel
 * @see app/Http/Controllers/Sales/InvoiceController.php:222
 * @route '/sales/invoices/{sale}/cancel'
 */
        cancelForm.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, options),
            method: 'post',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\Sales\InvoiceController::returnMethod
 * @see app/Http/Controllers/Sales/InvoiceController.php:238
 * @route '/sales/invoices/{sale}/return'
 */
export const returnMethod = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnMethod.url(args, options),
    method: 'post',
})

returnMethod.definition = {
    methods: ["post"],
    url: '/sales/invoices/{sale}/return',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sales\InvoiceController::returnMethod
 * @see app/Http/Controllers/Sales/InvoiceController.php:238
 * @route '/sales/invoices/{sale}/return'
 */
returnMethod.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sale: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sale: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sale: typeof args.sale === 'object'
                ? args.sale.id
                : args.sale,
                }

    return returnMethod.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\InvoiceController::returnMethod
 * @see app/Http/Controllers/Sales/InvoiceController.php:238
 * @route '/sales/invoices/{sale}/return'
 */
returnMethod.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: returnMethod.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sales\InvoiceController::returnMethod
 * @see app/Http/Controllers/Sales/InvoiceController.php:238
 * @route '/sales/invoices/{sale}/return'
 */
    const returnMethodForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: returnMethod.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\InvoiceController::returnMethod
 * @see app/Http/Controllers/Sales/InvoiceController.php:238
 * @route '/sales/invoices/{sale}/return'
 */
        returnMethodForm.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: returnMethod.url(args, options),
            method: 'post',
        })
    
    returnMethod.form = returnMethodForm
/**
* @see \App\Http\Controllers\Sales\InvoiceController::retryCourier
 * @see app/Http/Controllers/Sales/InvoiceController.php:250
 * @route '/sales/invoices/{sale}/retry-courier'
 */
export const retryCourier = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retryCourier.url(args, options),
    method: 'post',
})

retryCourier.definition = {
    methods: ["post"],
    url: '/sales/invoices/{sale}/retry-courier',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sales\InvoiceController::retryCourier
 * @see app/Http/Controllers/Sales/InvoiceController.php:250
 * @route '/sales/invoices/{sale}/retry-courier'
 */
retryCourier.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sale: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sale: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sale: typeof args.sale === 'object'
                ? args.sale.id
                : args.sale,
                }

    return retryCourier.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\InvoiceController::retryCourier
 * @see app/Http/Controllers/Sales/InvoiceController.php:250
 * @route '/sales/invoices/{sale}/retry-courier'
 */
retryCourier.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retryCourier.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sales\InvoiceController::retryCourier
 * @see app/Http/Controllers/Sales/InvoiceController.php:250
 * @route '/sales/invoices/{sale}/retry-courier'
 */
    const retryCourierForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: retryCourier.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\InvoiceController::retryCourier
 * @see app/Http/Controllers/Sales/InvoiceController.php:250
 * @route '/sales/invoices/{sale}/retry-courier'
 */
        retryCourierForm.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: retryCourier.url(args, options),
            method: 'post',
        })
    
    retryCourier.form = retryCourierForm
/**
* @see \App\Http\Controllers\Sales\InvoiceController::downloadPdf
 * @see app/Http/Controllers/Sales/InvoiceController.php:290
 * @route '/sales/invoices/{sale}/pdf'
 */
export const downloadPdf = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadPdf.url(args, options),
    method: 'get',
})

downloadPdf.definition = {
    methods: ["get","head"],
    url: '/sales/invoices/{sale}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\InvoiceController::downloadPdf
 * @see app/Http/Controllers/Sales/InvoiceController.php:290
 * @route '/sales/invoices/{sale}/pdf'
 */
downloadPdf.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sale: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sale: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sale: typeof args.sale === 'object'
                ? args.sale.id
                : args.sale,
                }

    return downloadPdf.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\InvoiceController::downloadPdf
 * @see app/Http/Controllers/Sales/InvoiceController.php:290
 * @route '/sales/invoices/{sale}/pdf'
 */
downloadPdf.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadPdf.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\InvoiceController::downloadPdf
 * @see app/Http/Controllers/Sales/InvoiceController.php:290
 * @route '/sales/invoices/{sale}/pdf'
 */
downloadPdf.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadPdf.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\InvoiceController::downloadPdf
 * @see app/Http/Controllers/Sales/InvoiceController.php:290
 * @route '/sales/invoices/{sale}/pdf'
 */
    const downloadPdfForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadPdf.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\InvoiceController::downloadPdf
 * @see app/Http/Controllers/Sales/InvoiceController.php:290
 * @route '/sales/invoices/{sale}/pdf'
 */
        downloadPdfForm.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadPdf.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\InvoiceController::downloadPdf
 * @see app/Http/Controllers/Sales/InvoiceController.php:290
 * @route '/sales/invoices/{sale}/pdf'
 */
        downloadPdfForm.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadPdf.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadPdf.form = downloadPdfForm
/**
* @see \App\Http\Controllers\Sales\InvoiceController::print
 * @see app/Http/Controllers/Sales/InvoiceController.php:303
 * @route '/sales/invoices/{sale}/print'
 */
export const print = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})

print.definition = {
    methods: ["get","head"],
    url: '/sales/invoices/{sale}/print',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Sales\InvoiceController::print
 * @see app/Http/Controllers/Sales/InvoiceController.php:303
 * @route '/sales/invoices/{sale}/print'
 */
print.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sale: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sale: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sale: typeof args.sale === 'object'
                ? args.sale.id
                : args.sale,
                }

    return print.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\InvoiceController::print
 * @see app/Http/Controllers/Sales/InvoiceController.php:303
 * @route '/sales/invoices/{sale}/print'
 */
print.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: print.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Sales\InvoiceController::print
 * @see app/Http/Controllers/Sales/InvoiceController.php:303
 * @route '/sales/invoices/{sale}/print'
 */
print.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: print.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Sales\InvoiceController::print
 * @see app/Http/Controllers/Sales/InvoiceController.php:303
 * @route '/sales/invoices/{sale}/print'
 */
    const printForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: print.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Sales\InvoiceController::print
 * @see app/Http/Controllers/Sales/InvoiceController.php:303
 * @route '/sales/invoices/{sale}/print'
 */
        printForm.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: print.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Sales\InvoiceController::print
 * @see app/Http/Controllers/Sales/InvoiceController.php:303
 * @route '/sales/invoices/{sale}/print'
 */
        printForm.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: print.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    print.form = printForm
const InvoiceController = { index, show, items, addPayment, cancel, returnMethod, retryCourier, downloadPdf, print, return: returnMethod }

export default InvoiceController