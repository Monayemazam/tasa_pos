import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Sales\SalePaymentController::store
 * @see app/Http/Controllers/Sales/SalePaymentController.php:23
 * @route '/sales/{sale}/payments'
 */
export const store = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/sales/{sale}/payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Sales\SalePaymentController::store
 * @see app/Http/Controllers/Sales/SalePaymentController.php:23
 * @route '/sales/{sale}/payments'
 */
store.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sale: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sale: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sale: typeof args.sale === 'object'
                ? args.sale.id
                : args.sale,
                }

    return store.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Sales\SalePaymentController::store
 * @see app/Http/Controllers/Sales/SalePaymentController.php:23
 * @route '/sales/{sale}/payments'
 */
store.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Sales\SalePaymentController::store
 * @see app/Http/Controllers/Sales/SalePaymentController.php:23
 * @route '/sales/{sale}/payments'
 */
    const storeForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Sales\SalePaymentController::store
 * @see app/Http/Controllers/Sales/SalePaymentController.php:23
 * @route '/sales/{sale}/payments'
 */
        storeForm.post = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const SalePaymentController = { store }

export default SalePaymentController