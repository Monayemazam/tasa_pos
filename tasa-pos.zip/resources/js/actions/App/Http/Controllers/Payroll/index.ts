import EmployeeController from './EmployeeController'
import SalaryMonthController from './SalaryMonthController'
import SalaryPaymentController from './SalaryPaymentController'
import WorkerController from './WorkerController'
import WorkerEarningController from './WorkerEarningController'
import WorkerPaymentController from './WorkerPaymentController'
const Payroll = {
    EmployeeController: Object.assign(EmployeeController, EmployeeController),
SalaryMonthController: Object.assign(SalaryMonthController, SalaryMonthController),
SalaryPaymentController: Object.assign(SalaryPaymentController, SalaryPaymentController),
WorkerController: Object.assign(WorkerController, WorkerController),
WorkerEarningController: Object.assign(WorkerEarningController, WorkerEarningController),
WorkerPaymentController: Object.assign(WorkerPaymentController, WorkerPaymentController),
}

export default Payroll