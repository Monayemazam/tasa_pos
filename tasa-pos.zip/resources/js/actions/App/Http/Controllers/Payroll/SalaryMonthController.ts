import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults, validateParameters } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::generate
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:23
 * @route '/payroll/months/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/payroll/months/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::generate
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:23
 * @route '/payroll/months/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::generate
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:23
 * @route '/payroll/months/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::generate
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:23
 * @route '/payroll/months/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::generate
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:23
 * @route '/payroll/months/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::update
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:38
 * @route '/payroll/months/{salaryMonth?}'
 */
export const update = (args?: { salaryMonth?: number | { id: number } } | [salaryMonth: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/payroll/months/{salaryMonth?}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::update
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:38
 * @route '/payroll/months/{salaryMonth?}'
 */
update.url = (args?: { salaryMonth?: number | { id: number } } | [salaryMonth: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salaryMonth: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salaryMonth: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salaryMonth: args[0],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "salaryMonth",
        ])

    const parsedArgs = {
                        salaryMonth: typeof args?.salaryMonth === 'object'
                ? args.salaryMonth.id
                : args?.salaryMonth,
                }

    return update.definition.url
            .replace('{salaryMonth?}', parsedArgs.salaryMonth?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::update
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:38
 * @route '/payroll/months/{salaryMonth?}'
 */
update.put = (args?: { salaryMonth?: number | { id: number } } | [salaryMonth: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::update
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:38
 * @route '/payroll/months/{salaryMonth?}'
 */
    const updateForm = (args?: { salaryMonth?: number | { id: number } } | [salaryMonth: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\SalaryMonthController::update
 * @see app/Http/Controllers/Payroll/SalaryMonthController.php:38
 * @route '/payroll/months/{salaryMonth?}'
 */
        updateForm.put = (args?: { salaryMonth?: number | { id: number } } | [salaryMonth: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const SalaryMonthController = { generate, update }

export default SalaryMonthController