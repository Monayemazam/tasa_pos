import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::store
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:23
 * @route '/payroll/payments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/payroll/payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::store
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:23
 * @route '/payroll/payments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::store
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:23
 * @route '/payroll/payments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::store
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:23
 * @route '/payroll/payments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::store
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:23
 * @route '/payroll/payments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::update
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:40
 * @route '/payroll/payments/{salaryPayment}'
 */
export const update = (args: { salaryPayment: number | { id: number } } | [salaryPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/payroll/payments/{salaryPayment}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::update
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:40
 * @route '/payroll/payments/{salaryPayment}'
 */
update.url = (args: { salaryPayment: number | { id: number } } | [salaryPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { salaryPayment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { salaryPayment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    salaryPayment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        salaryPayment: typeof args.salaryPayment === 'object'
                ? args.salaryPayment.id
                : args.salaryPayment,
                }

    return update.definition.url
            .replace('{salaryPayment}', parsedArgs.salaryPayment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::update
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:40
 * @route '/payroll/payments/{salaryPayment}'
 */
update.put = (args: { salaryPayment: number | { id: number } } | [salaryPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::update
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:40
 * @route '/payroll/payments/{salaryPayment}'
 */
    const updateForm = (args: { salaryPayment: number | { id: number } } | [salaryPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\SalaryPaymentController::update
 * @see app/Http/Controllers/Payroll/SalaryPaymentController.php:40
 * @route '/payroll/payments/{salaryPayment}'
 */
        updateForm.put = (args: { salaryPayment: number | { id: number } } | [salaryPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const SalaryPaymentController = { store, update }

export default SalaryPaymentController