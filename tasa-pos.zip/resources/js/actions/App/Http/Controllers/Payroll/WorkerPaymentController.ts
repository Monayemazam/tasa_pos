import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::store
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:23
 * @route '/payroll/workers/payments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/payroll/workers/payments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::store
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:23
 * @route '/payroll/workers/payments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::store
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:23
 * @route '/payroll/workers/payments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::store
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:23
 * @route '/payroll/workers/payments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::store
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:23
 * @route '/payroll/workers/payments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::update
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:38
 * @route '/payroll/workers/payments/{workerPayment}'
 */
export const update = (args: { workerPayment: number | { id: number } } | [workerPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/payroll/workers/payments/{workerPayment}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::update
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:38
 * @route '/payroll/workers/payments/{workerPayment}'
 */
update.url = (args: { workerPayment: number | { id: number } } | [workerPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workerPayment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workerPayment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workerPayment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workerPayment: typeof args.workerPayment === 'object'
                ? args.workerPayment.id
                : args.workerPayment,
                }

    return update.definition.url
            .replace('{workerPayment}', parsedArgs.workerPayment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::update
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:38
 * @route '/payroll/workers/payments/{workerPayment}'
 */
update.put = (args: { workerPayment: number | { id: number } } | [workerPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::update
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:38
 * @route '/payroll/workers/payments/{workerPayment}'
 */
    const updateForm = (args: { workerPayment: number | { id: number } } | [workerPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerPaymentController::update
 * @see app/Http/Controllers/Payroll/WorkerPaymentController.php:38
 * @route '/payroll/workers/payments/{workerPayment}'
 */
        updateForm.put = (args: { workerPayment: number | { id: number } } | [workerPayment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const WorkerPaymentController = { store, update }

export default WorkerPaymentController