import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\WorkerController::index
 * @see app/Http/Controllers/Payroll/WorkerController.php:31
 * @route '/payroll/workers'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/payroll/workers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerController::index
 * @see app/Http/Controllers/Payroll/WorkerController.php:31
 * @route '/payroll/workers'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerController::index
 * @see app/Http/Controllers/Payroll/WorkerController.php:31
 * @route '/payroll/workers'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\WorkerController::index
 * @see app/Http/Controllers/Payroll/WorkerController.php:31
 * @route '/payroll/workers'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerController::index
 * @see app/Http/Controllers/Payroll/WorkerController.php:31
 * @route '/payroll/workers'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerController::index
 * @see app/Http/Controllers/Payroll/WorkerController.php:31
 * @route '/payroll/workers'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\WorkerController::index
 * @see app/Http/Controllers/Payroll/WorkerController.php:31
 * @route '/payroll/workers'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Payroll\WorkerController::store
 * @see app/Http/Controllers/Payroll/WorkerController.php:96
 * @route '/payroll/workers'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/payroll/workers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerController::store
 * @see app/Http/Controllers/Payroll/WorkerController.php:96
 * @route '/payroll/workers'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerController::store
 * @see app/Http/Controllers/Payroll/WorkerController.php:96
 * @route '/payroll/workers'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerController::store
 * @see app/Http/Controllers/Payroll/WorkerController.php:96
 * @route '/payroll/workers'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerController::store
 * @see app/Http/Controllers/Payroll/WorkerController.php:96
 * @route '/payroll/workers'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Payroll\WorkerController::show
 * @see app/Http/Controllers/Payroll/WorkerController.php:108
 * @route '/payroll/workers/{worker}'
 */
export const show = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/payroll/workers/{worker}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerController::show
 * @see app/Http/Controllers/Payroll/WorkerController.php:108
 * @route '/payroll/workers/{worker}'
 */
show.url = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { worker: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { worker: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    worker: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        worker: typeof args.worker === 'object'
                ? args.worker.id
                : args.worker,
                }

    return show.definition.url
            .replace('{worker}', parsedArgs.worker.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerController::show
 * @see app/Http/Controllers/Payroll/WorkerController.php:108
 * @route '/payroll/workers/{worker}'
 */
show.get = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\WorkerController::show
 * @see app/Http/Controllers/Payroll/WorkerController.php:108
 * @route '/payroll/workers/{worker}'
 */
show.head = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerController::show
 * @see app/Http/Controllers/Payroll/WorkerController.php:108
 * @route '/payroll/workers/{worker}'
 */
    const showForm = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerController::show
 * @see app/Http/Controllers/Payroll/WorkerController.php:108
 * @route '/payroll/workers/{worker}'
 */
        showForm.get = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\WorkerController::show
 * @see app/Http/Controllers/Payroll/WorkerController.php:108
 * @route '/payroll/workers/{worker}'
 */
        showForm.head = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Payroll\WorkerController::update
 * @see app/Http/Controllers/Payroll/WorkerController.php:120
 * @route '/payroll/workers/{worker}'
 */
export const update = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/payroll/workers/{worker}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerController::update
 * @see app/Http/Controllers/Payroll/WorkerController.php:120
 * @route '/payroll/workers/{worker}'
 */
update.url = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { worker: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { worker: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    worker: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        worker: typeof args.worker === 'object'
                ? args.worker.id
                : args.worker,
                }

    return update.definition.url
            .replace('{worker}', parsedArgs.worker.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerController::update
 * @see app/Http/Controllers/Payroll/WorkerController.php:120
 * @route '/payroll/workers/{worker}'
 */
update.put = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerController::update
 * @see app/Http/Controllers/Payroll/WorkerController.php:120
 * @route '/payroll/workers/{worker}'
 */
    const updateForm = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerController::update
 * @see app/Http/Controllers/Payroll/WorkerController.php:120
 * @route '/payroll/workers/{worker}'
 */
        updateForm.put = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Payroll\WorkerController::destroy
 * @see app/Http/Controllers/Payroll/WorkerController.php:132
 * @route '/payroll/workers/{worker}'
 */
export const destroy = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/payroll/workers/{worker}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerController::destroy
 * @see app/Http/Controllers/Payroll/WorkerController.php:132
 * @route '/payroll/workers/{worker}'
 */
destroy.url = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { worker: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { worker: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    worker: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        worker: typeof args.worker === 'object'
                ? args.worker.id
                : args.worker,
                }

    return destroy.definition.url
            .replace('{worker}', parsedArgs.worker.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerController::destroy
 * @see app/Http/Controllers/Payroll/WorkerController.php:132
 * @route '/payroll/workers/{worker}'
 */
destroy.delete = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerController::destroy
 * @see app/Http/Controllers/Payroll/WorkerController.php:132
 * @route '/payroll/workers/{worker}'
 */
    const destroyForm = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerController::destroy
 * @see app/Http/Controllers/Payroll/WorkerController.php:132
 * @route '/payroll/workers/{worker}'
 */
        destroyForm.delete = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Payroll\WorkerController::restore
 * @see app/Http/Controllers/Payroll/WorkerController.php:144
 * @route '/payroll/workers/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/payroll/workers/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerController::restore
 * @see app/Http/Controllers/Payroll/WorkerController.php:144
 * @route '/payroll/workers/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerController::restore
 * @see app/Http/Controllers/Payroll/WorkerController.php:144
 * @route '/payroll/workers/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerController::restore
 * @see app/Http/Controllers/Payroll/WorkerController.php:144
 * @route '/payroll/workers/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerController::restore
 * @see app/Http/Controllers/Payroll/WorkerController.php:144
 * @route '/payroll/workers/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Payroll\WorkerController::statement
 * @see app/Http/Controllers/Payroll/WorkerController.php:159
 * @route '/payroll/workers/{worker}/statement'
 */
export const statement = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statement.url(args, options),
    method: 'get',
})

statement.definition = {
    methods: ["get","head"],
    url: '/payroll/workers/{worker}/statement',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerController::statement
 * @see app/Http/Controllers/Payroll/WorkerController.php:159
 * @route '/payroll/workers/{worker}/statement'
 */
statement.url = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { worker: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { worker: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    worker: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        worker: typeof args.worker === 'object'
                ? args.worker.id
                : args.worker,
                }

    return statement.definition.url
            .replace('{worker}', parsedArgs.worker.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerController::statement
 * @see app/Http/Controllers/Payroll/WorkerController.php:159
 * @route '/payroll/workers/{worker}/statement'
 */
statement.get = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statement.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Payroll\WorkerController::statement
 * @see app/Http/Controllers/Payroll/WorkerController.php:159
 * @route '/payroll/workers/{worker}/statement'
 */
statement.head = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: statement.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerController::statement
 * @see app/Http/Controllers/Payroll/WorkerController.php:159
 * @route '/payroll/workers/{worker}/statement'
 */
    const statementForm = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: statement.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerController::statement
 * @see app/Http/Controllers/Payroll/WorkerController.php:159
 * @route '/payroll/workers/{worker}/statement'
 */
        statementForm.get = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: statement.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Payroll\WorkerController::statement
 * @see app/Http/Controllers/Payroll/WorkerController.php:159
 * @route '/payroll/workers/{worker}/statement'
 */
        statementForm.head = (args: { worker: number | { id: number } } | [worker: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: statement.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    statement.form = statementForm
/**
* @see \App\Http\Controllers\Payroll\WorkerController::batchPayout
 * @see app/Http/Controllers/Payroll/WorkerController.php:185
 * @route '/payroll/workers/batch-payout'
 */
export const batchPayout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: batchPayout.url(options),
    method: 'post',
})

batchPayout.definition = {
    methods: ["post"],
    url: '/payroll/workers/batch-payout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerController::batchPayout
 * @see app/Http/Controllers/Payroll/WorkerController.php:185
 * @route '/payroll/workers/batch-payout'
 */
batchPayout.url = (options?: RouteQueryOptions) => {
    return batchPayout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerController::batchPayout
 * @see app/Http/Controllers/Payroll/WorkerController.php:185
 * @route '/payroll/workers/batch-payout'
 */
batchPayout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: batchPayout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerController::batchPayout
 * @see app/Http/Controllers/Payroll/WorkerController.php:185
 * @route '/payroll/workers/batch-payout'
 */
    const batchPayoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: batchPayout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerController::batchPayout
 * @see app/Http/Controllers/Payroll/WorkerController.php:185
 * @route '/payroll/workers/batch-payout'
 */
        batchPayoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: batchPayout.url(options),
            method: 'post',
        })
    
    batchPayout.form = batchPayoutForm
const WorkerController = { index, store, show, update, destroy, restore, statement, batchPayout }

export default WorkerController