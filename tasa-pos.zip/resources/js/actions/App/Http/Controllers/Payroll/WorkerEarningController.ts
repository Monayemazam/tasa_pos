import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::store
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:23
 * @route '/payroll/workers/earnings'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/payroll/workers/earnings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::store
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:23
 * @route '/payroll/workers/earnings'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::store
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:23
 * @route '/payroll/workers/earnings'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::store
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:23
 * @route '/payroll/workers/earnings'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::store
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:23
 * @route '/payroll/workers/earnings'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::update
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:38
 * @route '/payroll/workers/earnings/{workerEarning}'
 */
export const update = (args: { workerEarning: number | { id: number } } | [workerEarning: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/payroll/workers/earnings/{workerEarning}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::update
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:38
 * @route '/payroll/workers/earnings/{workerEarning}'
 */
update.url = (args: { workerEarning: number | { id: number } } | [workerEarning: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workerEarning: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workerEarning: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workerEarning: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workerEarning: typeof args.workerEarning === 'object'
                ? args.workerEarning.id
                : args.workerEarning,
                }

    return update.definition.url
            .replace('{workerEarning}', parsedArgs.workerEarning.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::update
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:38
 * @route '/payroll/workers/earnings/{workerEarning}'
 */
update.put = (args: { workerEarning: number | { id: number } } | [workerEarning: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::update
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:38
 * @route '/payroll/workers/earnings/{workerEarning}'
 */
    const updateForm = (args: { workerEarning: number | { id: number } } | [workerEarning: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Payroll\WorkerEarningController::update
 * @see app/Http/Controllers/Payroll/WorkerEarningController.php:38
 * @route '/payroll/workers/earnings/{workerEarning}'
 */
        updateForm.put = (args: { workerEarning: number | { id: number } } | [workerEarning: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const WorkerEarningController = { store, update }

export default WorkerEarningController