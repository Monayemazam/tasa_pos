import ProfileController from './ProfileController'
import SecurityController from './SecurityController'
import UserController from './UserController'
import RoleController from './RoleController'
import SystemSettingController from './SystemSettingController'
import AuditLogController from './AuditLogController'
const Settings = {
    ProfileController: Object.assign(ProfileController, ProfileController),
SecurityController: Object.assign(SecurityController, SecurityController),
UserController: Object.assign(UserController, UserController),
RoleController: Object.assign(RoleController, RoleController),
SystemSettingController: Object.assign(SystemSettingController, SystemSettingController),
AuditLogController: Object.assign(AuditLogController, AuditLogController),
}

export default Settings