import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::general
 * @see app/Http/Controllers/Settings/SystemSettingController.php:22
 * @route '/settings/general'
 */
export const general = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general.url(options),
    method: 'get',
})

general.definition = {
    methods: ["get","head"],
    url: '/settings/general',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::general
 * @see app/Http/Controllers/Settings/SystemSettingController.php:22
 * @route '/settings/general'
 */
general.url = (options?: RouteQueryOptions) => {
    return general.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::general
 * @see app/Http/Controllers/Settings/SystemSettingController.php:22
 * @route '/settings/general'
 */
general.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: general.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::general
 * @see app/Http/Controllers/Settings/SystemSettingController.php:22
 * @route '/settings/general'
 */
general.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: general.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::general
 * @see app/Http/Controllers/Settings/SystemSettingController.php:22
 * @route '/settings/general'
 */
    const generalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: general.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::general
 * @see app/Http/Controllers/Settings/SystemSettingController.php:22
 * @route '/settings/general'
 */
        generalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: general.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::general
 * @see app/Http/Controllers/Settings/SystemSettingController.php:22
 * @route '/settings/general'
 */
        generalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: general.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    general.form = generalForm
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateGeneral
 * @see app/Http/Controllers/Settings/SystemSettingController.php:51
 * @route '/settings/general'
 */
export const updateGeneral = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateGeneral.url(options),
    method: 'post',
})

updateGeneral.definition = {
    methods: ["post"],
    url: '/settings/general',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateGeneral
 * @see app/Http/Controllers/Settings/SystemSettingController.php:51
 * @route '/settings/general'
 */
updateGeneral.url = (options?: RouteQueryOptions) => {
    return updateGeneral.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateGeneral
 * @see app/Http/Controllers/Settings/SystemSettingController.php:51
 * @route '/settings/general'
 */
updateGeneral.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateGeneral.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateGeneral
 * @see app/Http/Controllers/Settings/SystemSettingController.php:51
 * @route '/settings/general'
 */
    const updateGeneralForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateGeneral.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateGeneral
 * @see app/Http/Controllers/Settings/SystemSettingController.php:51
 * @route '/settings/general'
 */
        updateGeneralForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateGeneral.url(options),
            method: 'post',
        })
    
    updateGeneral.form = updateGeneralForm
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::storeCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:334
 * @route '/settings/categories'
 */
export const storeCategory = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

storeCategory.definition = {
    methods: ["post"],
    url: '/settings/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::storeCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:334
 * @route '/settings/categories'
 */
storeCategory.url = (options?: RouteQueryOptions) => {
    return storeCategory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::storeCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:334
 * @route '/settings/categories'
 */
storeCategory.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::storeCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:334
 * @route '/settings/categories'
 */
    const storeCategoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeCategory.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::storeCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:334
 * @route '/settings/categories'
 */
        storeCategoryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeCategory.url(options),
            method: 'post',
        })
    
    storeCategory.form = storeCategoryForm
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::destroyCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:352
 * @route '/settings/categories/{category}'
 */
export const destroyCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

destroyCategory.definition = {
    methods: ["delete"],
    url: '/settings/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::destroyCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:352
 * @route '/settings/categories/{category}'
 */
destroyCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return destroyCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::destroyCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:352
 * @route '/settings/categories/{category}'
 */
destroyCategory.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::destroyCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:352
 * @route '/settings/categories/{category}'
 */
    const destroyCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyCategory.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::destroyCategory
 * @see app/Http/Controllers/Settings/SystemSettingController.php:352
 * @route '/settings/categories/{category}'
 */
        destroyCategoryForm.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyCategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyCategory.form = destroyCategoryForm
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::invoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:100
 * @route '/settings/invoice'
 */
export const invoice = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: invoice.url(options),
    method: 'get',
})

invoice.definition = {
    methods: ["get","head"],
    url: '/settings/invoice',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::invoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:100
 * @route '/settings/invoice'
 */
invoice.url = (options?: RouteQueryOptions) => {
    return invoice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::invoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:100
 * @route '/settings/invoice'
 */
invoice.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: invoice.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::invoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:100
 * @route '/settings/invoice'
 */
invoice.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: invoice.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::invoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:100
 * @route '/settings/invoice'
 */
    const invoiceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: invoice.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::invoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:100
 * @route '/settings/invoice'
 */
        invoiceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: invoice.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::invoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:100
 * @route '/settings/invoice'
 */
        invoiceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: invoice.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    invoice.form = invoiceForm
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateInvoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:137
 * @route '/settings/invoice'
 */
export const updateInvoice = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateInvoice.url(options),
    method: 'post',
})

updateInvoice.definition = {
    methods: ["post"],
    url: '/settings/invoice',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateInvoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:137
 * @route '/settings/invoice'
 */
updateInvoice.url = (options?: RouteQueryOptions) => {
    return updateInvoice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateInvoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:137
 * @route '/settings/invoice'
 */
updateInvoice.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateInvoice.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateInvoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:137
 * @route '/settings/invoice'
 */
    const updateInvoiceForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateInvoice.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::updateInvoice
 * @see app/Http/Controllers/Settings/SystemSettingController.php:137
 * @route '/settings/invoice'
 */
        updateInvoiceForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateInvoice.url(options),
            method: 'post',
        })
    
    updateInvoice.form = updateInvoiceForm
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::pathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:226
 * @route '/settings/pathao'
 */
export const pathao = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pathao.url(options),
    method: 'get',
})

pathao.definition = {
    methods: ["get","head"],
    url: '/settings/pathao',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::pathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:226
 * @route '/settings/pathao'
 */
pathao.url = (options?: RouteQueryOptions) => {
    return pathao.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::pathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:226
 * @route '/settings/pathao'
 */
pathao.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pathao.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::pathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:226
 * @route '/settings/pathao'
 */
pathao.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pathao.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::pathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:226
 * @route '/settings/pathao'
 */
    const pathaoForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pathao.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::pathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:226
 * @route '/settings/pathao'
 */
        pathaoForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pathao.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::pathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:226
 * @route '/settings/pathao'
 */
        pathaoForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pathao.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pathao.form = pathaoForm
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::updatePathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:293
 * @route '/settings/pathao'
 */
export const updatePathao = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePathao.url(options),
    method: 'post',
})

updatePathao.definition = {
    methods: ["post"],
    url: '/settings/pathao',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::updatePathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:293
 * @route '/settings/pathao'
 */
updatePathao.url = (options?: RouteQueryOptions) => {
    return updatePathao.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::updatePathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:293
 * @route '/settings/pathao'
 */
updatePathao.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updatePathao.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::updatePathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:293
 * @route '/settings/pathao'
 */
    const updatePathaoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePathao.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::updatePathao
 * @see app/Http/Controllers/Settings/SystemSettingController.php:293
 * @route '/settings/pathao'
 */
        updatePathaoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePathao.url(options),
            method: 'post',
        })
    
    updatePathao.form = updatePathaoForm
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::testPathaoConnection
 * @see app/Http/Controllers/Settings/SystemSettingController.php:256
 * @route '/settings/pathao/test-connection'
 */
export const testPathaoConnection = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: testPathaoConnection.url(options),
    method: 'get',
})

testPathaoConnection.definition = {
    methods: ["get","head"],
    url: '/settings/pathao/test-connection',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::testPathaoConnection
 * @see app/Http/Controllers/Settings/SystemSettingController.php:256
 * @route '/settings/pathao/test-connection'
 */
testPathaoConnection.url = (options?: RouteQueryOptions) => {
    return testPathaoConnection.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::testPathaoConnection
 * @see app/Http/Controllers/Settings/SystemSettingController.php:256
 * @route '/settings/pathao/test-connection'
 */
testPathaoConnection.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: testPathaoConnection.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::testPathaoConnection
 * @see app/Http/Controllers/Settings/SystemSettingController.php:256
 * @route '/settings/pathao/test-connection'
 */
testPathaoConnection.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: testPathaoConnection.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::testPathaoConnection
 * @see app/Http/Controllers/Settings/SystemSettingController.php:256
 * @route '/settings/pathao/test-connection'
 */
    const testPathaoConnectionForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: testPathaoConnection.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::testPathaoConnection
 * @see app/Http/Controllers/Settings/SystemSettingController.php:256
 * @route '/settings/pathao/test-connection'
 */
        testPathaoConnectionForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: testPathaoConnection.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::testPathaoConnection
 * @see app/Http/Controllers/Settings/SystemSettingController.php:256
 * @route '/settings/pathao/test-connection'
 */
        testPathaoConnectionForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: testPathaoConnection.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    testPathaoConnection.form = testPathaoConnectionForm
/**
* @see \App\Http\Controllers\Settings\SystemSettingController::createPathaoStore
 * @see app/Http/Controllers/Settings/SystemSettingController.php:266
 * @route '/settings/pathao/stores'
 */
export const createPathaoStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createPathaoStore.url(options),
    method: 'post',
})

createPathaoStore.definition = {
    methods: ["post"],
    url: '/settings/pathao/stores',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::createPathaoStore
 * @see app/Http/Controllers/Settings/SystemSettingController.php:266
 * @route '/settings/pathao/stores'
 */
createPathaoStore.url = (options?: RouteQueryOptions) => {
    return createPathaoStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\SystemSettingController::createPathaoStore
 * @see app/Http/Controllers/Settings/SystemSettingController.php:266
 * @route '/settings/pathao/stores'
 */
createPathaoStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createPathaoStore.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\SystemSettingController::createPathaoStore
 * @see app/Http/Controllers/Settings/SystemSettingController.php:266
 * @route '/settings/pathao/stores'
 */
    const createPathaoStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: createPathaoStore.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\SystemSettingController::createPathaoStore
 * @see app/Http/Controllers/Settings/SystemSettingController.php:266
 * @route '/settings/pathao/stores'
 */
        createPathaoStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: createPathaoStore.url(options),
            method: 'post',
        })
    
    createPathaoStore.form = createPathaoStoreForm
const SystemSettingController = { general, updateGeneral, storeCategory, destroyCategory, invoice, updateInvoice, pathao, updatePathao, testPathaoConnection, createPathaoStore }

export default SystemSettingController