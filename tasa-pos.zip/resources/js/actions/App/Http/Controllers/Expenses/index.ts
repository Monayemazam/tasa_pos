import ExpenseController from './ExpenseController'
const Expenses = {
    ExpenseController: Object.assign(ExpenseController, ExpenseController),
}

export default Expenses