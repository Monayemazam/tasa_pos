import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses/list'
 */
const index43f424711b3143539576b41877d57fdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index43f424711b3143539576b41877d57fdf.url(options),
    method: 'get',
})

index43f424711b3143539576b41877d57fdf.definition = {
    methods: ["get","head"],
    url: '/expenses/list',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses/list'
 */
index43f424711b3143539576b41877d57fdf.url = (options?: RouteQueryOptions) => {
    return index43f424711b3143539576b41877d57fdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses/list'
 */
index43f424711b3143539576b41877d57fdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index43f424711b3143539576b41877d57fdf.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses/list'
 */
index43f424711b3143539576b41877d57fdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index43f424711b3143539576b41877d57fdf.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses/list'
 */
    const index43f424711b3143539576b41877d57fdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index43f424711b3143539576b41877d57fdf.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses/list'
 */
        index43f424711b3143539576b41877d57fdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index43f424711b3143539576b41877d57fdf.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses/list'
 */
        index43f424711b3143539576b41877d57fdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index43f424711b3143539576b41877d57fdf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index43f424711b3143539576b41877d57fdf.form = index43f424711b3143539576b41877d57fdfForm
    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses'
 */
const indexf15427b4993b94dea5aadc475939b413 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexf15427b4993b94dea5aadc475939b413.url(options),
    method: 'get',
})

indexf15427b4993b94dea5aadc475939b413.definition = {
    methods: ["get","head"],
    url: '/expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses'
 */
indexf15427b4993b94dea5aadc475939b413.url = (options?: RouteQueryOptions) => {
    return indexf15427b4993b94dea5aadc475939b413.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses'
 */
indexf15427b4993b94dea5aadc475939b413.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexf15427b4993b94dea5aadc475939b413.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses'
 */
indexf15427b4993b94dea5aadc475939b413.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexf15427b4993b94dea5aadc475939b413.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses'
 */
    const indexf15427b4993b94dea5aadc475939b413Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: indexf15427b4993b94dea5aadc475939b413.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses'
 */
        indexf15427b4993b94dea5aadc475939b413Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexf15427b4993b94dea5aadc475939b413.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::index
 * @see app/Http/Controllers/Expenses/ExpenseController.php:33
 * @route '/expenses'
 */
        indexf15427b4993b94dea5aadc475939b413Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexf15427b4993b94dea5aadc475939b413.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    indexf15427b4993b94dea5aadc475939b413.form = indexf15427b4993b94dea5aadc475939b413Form

/**
* Multiple routes resolve to \App\Http\Controllers\Expenses\ExpenseController::index, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `index['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const index = {
    '/expenses/list': index43f424711b3143539576b41877d57fdf,
    '/expenses': indexf15427b4993b94dea5aadc475939b413,
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:78
 * @route '/expenses'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/expenses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:78
 * @route '/expenses'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:78
 * @route '/expenses'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:78
 * @route '/expenses'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::store
 * @see app/Http/Controllers/Expenses/ExpenseController.php:78
 * @route '/expenses'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:139
 * @route '/expenses/categories'
 */
export const storeCategory = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

storeCategory.definition = {
    methods: ["post"],
    url: '/expenses/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:139
 * @route '/expenses/categories'
 */
storeCategory.url = (options?: RouteQueryOptions) => {
    return storeCategory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:139
 * @route '/expenses/categories'
 */
storeCategory.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:139
 * @route '/expenses/categories'
 */
    const storeCategoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeCategory.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:139
 * @route '/expenses/categories'
 */
        storeCategoryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeCategory.url(options),
            method: 'post',
        })
    
    storeCategory.form = storeCategoryForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:149
 * @route '/expenses/categories/{category}'
 */
export const updateCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCategory.url(args, options),
    method: 'put',
})

updateCategory.definition = {
    methods: ["put"],
    url: '/expenses/categories/{category}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:149
 * @route '/expenses/categories/{category}'
 */
updateCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return updateCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:149
 * @route '/expenses/categories/{category}'
 */
updateCategory.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCategory.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:149
 * @route '/expenses/categories/{category}'
 */
    const updateCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateCategory.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:149
 * @route '/expenses/categories/{category}'
 */
        updateCategoryForm.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateCategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateCategory.form = updateCategoryForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:161
 * @route '/expenses/categories/{category}'
 */
export const destroyCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

destroyCategory.definition = {
    methods: ["delete"],
    url: '/expenses/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:161
 * @route '/expenses/categories/{category}'
 */
destroyCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return destroyCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:161
 * @route '/expenses/categories/{category}'
 */
destroyCategory.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:161
 * @route '/expenses/categories/{category}'
 */
    const destroyCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyCategory.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyCategory
 * @see app/Http/Controllers/Expenses/ExpenseController.php:161
 * @route '/expenses/categories/{category}'
 */
        destroyCategoryForm.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyCategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyCategory.form = destroyCategoryForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:173
 * @route '/expenses/recurring'
 */
export const storeRecurring = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRecurring.url(options),
    method: 'post',
})

storeRecurring.definition = {
    methods: ["post"],
    url: '/expenses/recurring',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:173
 * @route '/expenses/recurring'
 */
storeRecurring.url = (options?: RouteQueryOptions) => {
    return storeRecurring.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:173
 * @route '/expenses/recurring'
 */
storeRecurring.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRecurring.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:173
 * @route '/expenses/recurring'
 */
    const storeRecurringForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeRecurring.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::storeRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:173
 * @route '/expenses/recurring'
 */
        storeRecurringForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeRecurring.url(options),
            method: 'post',
        })
    
    storeRecurring.form = storeRecurringForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:183
 * @route '/expenses/recurring/{recurring}'
 */
export const updateRecurring = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateRecurring.url(args, options),
    method: 'put',
})

updateRecurring.definition = {
    methods: ["put"],
    url: '/expenses/recurring/{recurring}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:183
 * @route '/expenses/recurring/{recurring}'
 */
updateRecurring.url = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { recurring: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { recurring: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    recurring: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        recurring: typeof args.recurring === 'object'
                ? args.recurring.id
                : args.recurring,
                }

    return updateRecurring.definition.url
            .replace('{recurring}', parsedArgs.recurring.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:183
 * @route '/expenses/recurring/{recurring}'
 */
updateRecurring.put = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateRecurring.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:183
 * @route '/expenses/recurring/{recurring}'
 */
    const updateRecurringForm = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateRecurring.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::updateRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:183
 * @route '/expenses/recurring/{recurring}'
 */
        updateRecurringForm.put = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateRecurring.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateRecurring.form = updateRecurringForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:195
 * @route '/expenses/recurring/{recurring}'
 */
export const destroyRecurring = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyRecurring.url(args, options),
    method: 'delete',
})

destroyRecurring.definition = {
    methods: ["delete"],
    url: '/expenses/recurring/{recurring}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:195
 * @route '/expenses/recurring/{recurring}'
 */
destroyRecurring.url = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { recurring: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { recurring: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    recurring: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        recurring: typeof args.recurring === 'object'
                ? args.recurring.id
                : args.recurring,
                }

    return destroyRecurring.definition.url
            .replace('{recurring}', parsedArgs.recurring.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:195
 * @route '/expenses/recurring/{recurring}'
 */
destroyRecurring.delete = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyRecurring.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:195
 * @route '/expenses/recurring/{recurring}'
 */
    const destroyRecurringForm = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyRecurring.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroyRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:195
 * @route '/expenses/recurring/{recurring}'
 */
        destroyRecurringForm.delete = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyRecurring.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyRecurring.form = destroyRecurringForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::confirmRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:207
 * @route '/expenses/recurring/{recurring}/confirm'
 */
export const confirmRecurring = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirmRecurring.url(args, options),
    method: 'post',
})

confirmRecurring.definition = {
    methods: ["post"],
    url: '/expenses/recurring/{recurring}/confirm',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::confirmRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:207
 * @route '/expenses/recurring/{recurring}/confirm'
 */
confirmRecurring.url = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { recurring: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { recurring: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    recurring: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        recurring: typeof args.recurring === 'object'
                ? args.recurring.id
                : args.recurring,
                }

    return confirmRecurring.definition.url
            .replace('{recurring}', parsedArgs.recurring.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::confirmRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:207
 * @route '/expenses/recurring/{recurring}/confirm'
 */
confirmRecurring.post = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirmRecurring.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::confirmRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:207
 * @route '/expenses/recurring/{recurring}/confirm'
 */
    const confirmRecurringForm = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: confirmRecurring.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::confirmRecurring
 * @see app/Http/Controllers/Expenses/ExpenseController.php:207
 * @route '/expenses/recurring/{recurring}/confirm'
 */
        confirmRecurringForm.post = (args: { recurring: number | { id: number } } | [recurring: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: confirmRecurring.url(args, options),
            method: 'post',
        })
    
    confirmRecurring.form = confirmRecurringForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::downloadAttachment
 * @see app/Http/Controllers/Expenses/ExpenseController.php:121
 * @route '/expenses/{expense}/attachment'
 */
export const downloadAttachment = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadAttachment.url(args, options),
    method: 'get',
})

downloadAttachment.definition = {
    methods: ["get","head"],
    url: '/expenses/{expense}/attachment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::downloadAttachment
 * @see app/Http/Controllers/Expenses/ExpenseController.php:121
 * @route '/expenses/{expense}/attachment'
 */
downloadAttachment.url = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { expense: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    expense: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return downloadAttachment.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::downloadAttachment
 * @see app/Http/Controllers/Expenses/ExpenseController.php:121
 * @route '/expenses/{expense}/attachment'
 */
downloadAttachment.get = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadAttachment.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::downloadAttachment
 * @see app/Http/Controllers/Expenses/ExpenseController.php:121
 * @route '/expenses/{expense}/attachment'
 */
downloadAttachment.head = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadAttachment.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::downloadAttachment
 * @see app/Http/Controllers/Expenses/ExpenseController.php:121
 * @route '/expenses/{expense}/attachment'
 */
    const downloadAttachmentForm = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadAttachment.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::downloadAttachment
 * @see app/Http/Controllers/Expenses/ExpenseController.php:121
 * @route '/expenses/{expense}/attachment'
 */
        downloadAttachmentForm.get = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadAttachment.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::downloadAttachment
 * @see app/Http/Controllers/Expenses/ExpenseController.php:121
 * @route '/expenses/{expense}/attachment'
 */
        downloadAttachmentForm.head = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadAttachment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadAttachment.form = downloadAttachmentForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:92
 * @route '/expenses/{expense}'
 */
export const update = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","post"],
    url: '/expenses/{expense}',
} satisfies RouteDefinition<["put","post"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:92
 * @route '/expenses/{expense}'
 */
update.url = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { expense: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    expense: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return update.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:92
 * @route '/expenses/{expense}'
 */
update.put = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:92
 * @route '/expenses/{expense}'
 */
update.post = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:92
 * @route '/expenses/{expense}'
 */
    const updateForm = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:92
 * @route '/expenses/{expense}'
 */
        updateForm.put = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::update
 * @see app/Http/Controllers/Expenses/ExpenseController.php:92
 * @route '/expenses/{expense}'
 */
        updateForm.post = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:109
 * @route '/expenses/{expense}'
 */
export const destroy = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/expenses/{expense}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:109
 * @route '/expenses/{expense}'
 */
destroy.url = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { expense: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { expense: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    expense: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return destroy.definition.url
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:109
 * @route '/expenses/{expense}'
 */
destroy.delete = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:109
 * @route '/expenses/{expense}'
 */
    const destroyForm = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Expenses\ExpenseController::destroy
 * @see app/Http/Controllers/Expenses/ExpenseController.php:109
 * @route '/expenses/{expense}'
 */
        destroyForm.delete = (args: { expense: number | { id: number } } | [expense: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ExpenseController = { index, store, storeCategory, updateCategory, destroyCategory, storeRecurring, updateRecurring, destroyRecurring, confirmRecurring, downloadAttachment, update, destroy }

export default ExpenseController