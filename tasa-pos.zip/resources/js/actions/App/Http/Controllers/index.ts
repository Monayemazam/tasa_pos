import DashboardController from './DashboardController'
import SearchController from './SearchController'
import Sales from './Sales'
import Inventory from './Inventory'
import Expenses from './Expenses'
import Payroll from './Payroll'
import Reports from './Reports'
import Settings from './Settings'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
SearchController: Object.assign(SearchController, SearchController),
Sales: Object.assign(Sales, Sales),
Inventory: Object.assign(Inventory, Inventory),
Expenses: Object.assign(Expenses, Expenses),
Payroll: Object.assign(Payroll, Payroll),
Reports: Object.assign(Reports, Reports),
Settings: Object.assign(Settings, Settings),
}

export default Controllers